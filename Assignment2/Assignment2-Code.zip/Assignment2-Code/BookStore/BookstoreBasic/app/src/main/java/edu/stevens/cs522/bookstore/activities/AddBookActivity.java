package edu.stevens.cs522.bookstore.activities;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.EditText;
import android.widget.Toast;

import edu.stevens.cs522.bookstore.R;
import edu.stevens.cs522.bookstore.entities.Author;
import edu.stevens.cs522.bookstore.entities.Book;

public class AddBookActivity extends Activity {
	
	// Use this as the key to return the book details as a Parcelable extra in the result intent.
	public static final String BOOK_RESULT_KEY = "ADD_BOOK_RESULT";
	private EditText title, author, isbn;
    static int bookId = 1;
	
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.add_book);

        title = (EditText)findViewById(R.id.search_title);
        author = (EditText)findViewById(R.id.search_author);
        isbn = (EditText)findViewById(R.id.search_isbn);
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		super.onCreateOptionsMenu(menu);
		// TODO provide SEARCH and CANCEL options
        getMenuInflater().inflate(R.menu.add_book_menu, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		super.onOptionsItemSelected(item);
		// TODO
		switch(item.getItemId()){
            // SEARCH: return the book details to the BookStore activity
            case R.id.search:
                Intent intent = new Intent();

                //create book object using the values entered by the user
                Book book = searchBook();
                intent.putExtra(BOOK_RESULT_KEY, book);
                setResult(Activity.RESULT_OK, intent);
                finish();
                return true;

            // CANCEL: cancel the search request
            case R.id.cancel:
                finish();
                return true;
        }
		return false;
	}
	
	public Book searchBook(){
		/*
		 * Search for the specified book.
		 */
		// TODO Just build a Book object with the search criteria and return that.
        Book book = new Book();
        book.setId(bookId++);
        book.setTitle(title.getText().toString());  //Book Title

        //Book Authors
        String [] str = author.getText().toString().split(",");
        Author[] authors = new Author[str.length];
        int index = 0;
        for(String s : str){
            Author a = null;
            String[] fml = s.split("\\s+");
            if(fml.length == 1){
                a = new Author(fml[0].toString());
            }else if(fml.length == 2){
                a = new Author(fml[0], fml[1]);
            }else if(fml.length == 3){
                a = new Author(fml[0], fml[1], fml[2]);
            }else{
                Toast.makeText(this, "Invalid Author Name", Toast.LENGTH_LONG).show();
            }
            authors[index] = a;
            index++;
        }
        book.setAuthors(authors);

        book.setIsbn(isbn.getText().toString());    //Book ISBN
        book.setPrice("$200");  //Book Price
		return book;
	}
}