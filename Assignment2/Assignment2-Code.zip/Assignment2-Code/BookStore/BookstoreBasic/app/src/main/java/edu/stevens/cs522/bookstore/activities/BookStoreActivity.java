package edu.stevens.cs522.bookstore.activities;

import java.util.ArrayList;
import java.util.List;

import android.app.Activity;
import android.app.ListActivity;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.res.Resources;
import android.os.Bundle;
import android.util.Log;
import android.util.SparseBooleanArray;
import android.view.ActionMode;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import edu.stevens.cs522.bookstore.R;
import edu.stevens.cs522.bookstore.entities.Author;
import edu.stevens.cs522.bookstore.entities.Book;

public class BookStoreActivity extends ListActivity {
	
	// Use this when logging errors and warnings.
	@SuppressWarnings("unused")
	//private static final String TAG = BookStoreActivity.class.getCanonicalName();
	private static final String TAG = "BookStoreBasics_";
	
	// These are request codes for subactivity request calls
	static final private int ADD_REQUEST = 1;
	
	@SuppressWarnings("unused")
	static final private int CHECKOUT_REQUEST = ADD_REQUEST + 1;

	// There is a reason this must be an ArrayList instead of a List.
	@SuppressWarnings("unused")
	private ArrayList<Book> shoppingCart = new ArrayList<Book>();	//data source
    private ListView bookStoreListView;	//ListView
    static final private String cart = "list";
    private static final String BOOK_DETAILS = "Book_Details";

	//create the adapter to convert the array to views
	BookAdapter bAdapter;
	

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		// TODO Set the layout (use cart.xml layout)
		setContentView(R.layout.cart);


        // TODO check if there is saved UI state, and if so, restore it (i.e. the cart contents)
        if(savedInstanceState != null){
            shoppingCart = savedInstanceState.getParcelableArrayList("list");
        }

		shoppingCart = new ArrayList<Book>();

        // TODO use an array adapter to display the cart contents.
        bAdapter = new BookAdapter(this, shoppingCart);
		bookStoreListView = (ListView)findViewById(android.R.id.list);
	    bookStoreListView.setAdapter(bAdapter);

        // For Contextual Action Menu
        bookStoreListView.setChoiceMode(ListView.CHOICE_MODE_MULTIPLE_MODAL);
        bookStoreListView.setMultiChoiceModeListener(new AbsListView.MultiChoiceModeListener() {
            @Override
            public void onItemCheckedStateChanged(ActionMode mode, int position, long id, boolean checked) {
                mode.setTitle(bookStoreListView.getCheckedItemCount() + " selected Items");
            }

            @Override
            public boolean onCreateActionMode(ActionMode mode, Menu menu) {
                Log.i(TAG, "creating action mode");
                mode.getMenuInflater().inflate(R.menu.context_action_bar_menu, menu);
                return true;
            }

            @Override
            public boolean onPrepareActionMode(ActionMode mode, Menu menu) {
                return false;
            }

            @Override
            public boolean onActionItemClicked(ActionMode mode, MenuItem item) {
                switch (item.getItemId()) {
                    case R.id.menu_delete:
                        Log.i(TAG, "action item delete clicked");
                        doSomethingWithActionOneItems();
                        mode.finish();
                        return true;
                    default:
                        return false;
                }
            }

            @Override
            public void onDestroyActionMode(ActionMode mode) {
                Log.i(TAG, "destroying action mode");
            }
        });

        bookStoreListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent intent = new Intent(getApplicationContext(), DetailsActivity.class);
                intent.putExtra(BOOK_DETAILS, shoppingCart.get(position));
                startActivity(intent);
            }
        });
    }

    private void doSomethingWithActionOneItems(){

        Log.i(TAG, "getting actionone items delete");
        SparseBooleanArray checked = bookStoreListView.getCheckedItemPositions();

        Book [] books = new Book[checked.size()];
        
        for(int i =0; i < checked.size(); i++){
            if(checked.valueAt(i) == true){
                Book theSelectedBook = (Book) bookStoreListView.getItemAtPosition(checked.keyAt(i));
                Log.i(TAG, "selected Book title: " + theSelectedBook.title);

                books[i] = theSelectedBook;
                //bAdapter.remove(theSelectedBook);
                //bAdapter.notifyDataSetChanged();
            }else{
                Log.i(TAG, "Nothing selected");
            }
        }

        for(Book b : books){
            shoppingCart.remove(b);
        }
        bAdapter.notifyDataSetChanged();
    }

    public void sampleBooks(){

        Author[] author = new Author[3];
        author[0] = new Author("Mehul", "Sushilkumar" ,"Gupta");
        author[1] = new Author("Ankita", "Sanjay","Patel");
        author[2] = new Author("Dharti", null, "Patel");

        for(int i = 0; i<3; i++){
            Book book = new Book(i, "Book TItle"+i, author, "isbn"+i, "price"+i);
            shoppingCart.add(book);
        }
    }

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		super.onCreateOptionsMenu(menu);
		// TODO provide ADD, DELETE and CHECKOUT options
		MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.bookstore_menu, menu);
		return true;
	}

    Intent addIntent;
	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		super.onOptionsItemSelected(item);
		// TODO

        switch(item.getItemId()){
            case R.id.add:
                // ADD provide the UI for adding a book
                addIntent = new Intent(this, AddBookActivity.class);
                startActivityForResult(addIntent, ADD_REQUEST);
                return true;

            case R.id.details:
                // DELETE delete the currently selected book
                if(shoppingCart.size() <= 0){
                    Toast.makeText(this, "Cart is Empty! Nothing to Display!", Toast.LENGTH_LONG).show();
                }else{
                    addIntent = new Intent(this, DetailsActivity.class);
                    Book book = shoppingCart.get(0);
                    addIntent.putExtra(BOOK_DETAILS, book);
                    startActivity(addIntent);
                }
                return true;

            case R.id.checkout:
                // CHECKOUT provide the UI for checking out
                if(shoppingCart.size() < 0){
                    Toast.makeText(this, "Cart is Empty!!", Toast.LENGTH_LONG).show();
                }else{
                    addIntent = new Intent(this, CheckoutActivity.class);
                    startActivityForResult(addIntent, CHECKOUT_REQUEST);
                }
                return true;
        }
	return false;
	}

    @Override
    protected void onActivityResult(int requestCode, int resultCode,
                                    Intent intent) {
        super.onActivityResult(requestCode, resultCode, intent);
        // TODO Handle results from the Search and Checkout activities.
        // Use SEARCH_REQUEST and CHECKOUT_REQUEST codes to distinguish the cases.

        if(requestCode == ADD_REQUEST){ // SEARCH: add the book that is returned to the shopping cart.
            if(resultCode == RESULT_OK){
                Book b = intent.getExtras().getParcelable(AddBookActivity.BOOK_RESULT_KEY);
                Toast.makeText(this, "At the BookStoreActivity", Toast.LENGTH_LONG).show();
                shoppingCart.add(b);
                bAdapter.notifyDataSetChanged();


            }else if(resultCode == RESULT_CANCELED){
                Toast.makeText(this,"AddBook Cancelled",Toast.LENGTH_LONG).show();
            }
        }else if(requestCode == CHECKOUT_REQUEST){  // CHECKOUT: empty the shopping cart.
            if(resultCode == RESULT_OK){
                Toast.makeText(this,"books checked out",Toast.LENGTH_LONG).show();
                shoppingCart.clear();
                bAdapter.notifyDataSetChanged();


            }else if(resultCode == RESULT_CANCELED){
                Toast.makeText(this,"Checkout Cancelled",Toast.LENGTH_LONG).show();
            }
        }
    }

    @Override
	public void onSaveInstanceState(Bundle savedInstanceState) {
		// TODO save the shopping cart contents (which should be a list of parcelables).
		savedInstanceState.putParcelableArrayList(cart, shoppingCart);
	}
}


class BookAdapter extends ArrayAdapter<Book>{

    private SparseBooleanArray mSelectedItemIds;
    List<Book> books;

    //View Lookup Cache
    private static class ViewHolder{
        TextView title;
        TextView authors;
    }

    public BookAdapter(Context context, ArrayList<Book> shoppingCart){
        super(context, R.layout.cart_row, shoppingCart);
        mSelectedItemIds = new SparseBooleanArray();
        books = shoppingCart;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent){
        //Get data item for this position
        Book book = getItem(position);

        //check if an existing View is being reused, otherwise inflate the view
        ViewHolder viewHolder;	//view lookup cache stored in tag
        if(convertView == null){
            viewHolder = new ViewHolder();
            LayoutInflater inflater = LayoutInflater.from(getContext());
            convertView = inflater.inflate(R.layout.cart_row, parent, false);

            viewHolder.title = (TextView)convertView.findViewById(R.id.cart_row_title);
            viewHolder.authors = (TextView)convertView.findViewById(R.id.cart_row_author);

            convertView.setTag(viewHolder);
        }else{
            viewHolder = (ViewHolder)convertView.getTag();
        }

        //populate the data into the template view using the data object
        viewHolder.title.setText(book.title.toString());
        Author [] authors = book.authors;
        String authorsStr = "";
        int count=0;
        for(Author a : authors){
            authorsStr += a.firstName+" ";
            if(a.middleInitial != null){
                authorsStr += a.middleInitial+" ";
            }
            authorsStr += a.lastName;

            count++;
            if(count < authors.length){
                authorsStr += ", ";
            }
        }
        viewHolder.authors.setText(authorsStr);

        //return the completed view to render on screen
        return convertView;
    }

    public SparseBooleanArray getSelectedIds(){
        return mSelectedItemIds;
    }

    public int getSelectedCount(){
        return mSelectedItemIds.size();
    }

    public void removeSelection(){
        mSelectedItemIds = new SparseBooleanArray();
        notifyDataSetChanged();
    }

    public void remove(Book object){
        Log.i("Reomve", "removing book obj");
        books.remove(object);
        notifyDataSetChanged();
    }

    public void toggleSelection(int position){
        selectView(position, !mSelectedItemIds.get(position));
    }

    public void selectView(int position, boolean value){
        if(value){
            mSelectedItemIds.put(position, value);
        }else{
            mSelectedItemIds.delete(position);
        }
        notifyDataSetChanged();
    }
}