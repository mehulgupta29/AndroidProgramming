package edu.stevens.cs522.chat.twoway.interfaces;

import android.content.Intent;
import android.os.Message;

public interface IChatSendService {
	void send (Message message);
}
