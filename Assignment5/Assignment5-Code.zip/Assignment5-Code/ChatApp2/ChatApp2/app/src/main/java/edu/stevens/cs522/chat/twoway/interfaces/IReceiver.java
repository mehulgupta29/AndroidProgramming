package edu.stevens.cs522.chat.twoway.interfaces;

import android.os.Bundle;

/**
 * Created by DV6 on 3/6/2016.
 */
public interface IReceiver {
    void onReceiveResult(int resultCode, Bundle resultData);
}
