package edu.stevens.cs522.chat.twoway.interfaces;

public interface IContinue<T> {

	public void	kontinue(T value);
	
}
