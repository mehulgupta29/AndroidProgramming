package edu.stevens.cs522.chat.twoway.activities;

/**
 * Created by DV6 on 3/1/2016.
 */
public class constants {

    public	static	final	String	NEW_MESSAGE_BROADCAST = "edu.stevens.cs522.chat.NewMessageBroadcast";
    public static final String PORT = "port";
    public static final String PORT_VALUE = "6666";
    public static final String HOST = "host";
    public static final String TEXT_MESSAGE = "text_message";
    public static final String NAME = "name";
    public static final String saveClientNamePreferences = "SAVE_CLIENT_NAME_PREFERENCES";
    public static final int MSG_SEND = 1;
    public static final String MESSAGE_SEPERATOR = ",";
    public static final String MESSAGE_BROADCAST = "cs522.stevens.edu.chat.MessageBroadcast";
    public static final String MESSAGE = "MESSAGE";
    public static final String ADDRESS = "ADDRESS";
    public static final String RECEIVER = "RECEIVER";
}
