package edu.stevens.cs522.activities;

import java.util.ArrayList;
import java.util.Date;
import java.util.regex.Pattern;

import android.app.Activity;
import android.app.AlarmManager;
import android.app.LoaderManager;
import android.app.PendingIntent;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.content.CursorLoader;
import android.content.Intent;
import android.content.Loader;
import android.content.SharedPreferences;
import android.content.res.Resources;
import android.database.Cursor;
import android.os.Bundle;
import android.os.Handler;
import android.os.ResultReceiver;
import android.os.SystemClock;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CursorAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.SimpleCursorAdapter;
import android.widget.Toast;

import edu.stevens.cs522.constants.constant;
import edu.stevens.cs522.entities.ChatMessage;
import edu.stevens.cs522.chatappcloud.R;
import edu.stevens.cs522.helpers.ServiceHelper;
import edu.stevens.cs522.providers.CloudProvider;
import edu.stevens.cs522.services.AlarmReceiver;

public class ChatApp extends Activity implements LoaderManager.LoaderCallbacks<Cursor> {

    public final static String TAG = ChatApp.class.getCanonicalName();
	EditText msgTxt;
	Button send;

	private String clientName;
	private String portNo;
	private String hostStr;
	private String uuidStr;
    AlarmManager alarmManager;
	boolean mBound = false;

	ListView msgList;
	ContentResolver cr;
	public SimpleCursorAdapter msgAdapter;
	public String[] from = new String[] { CloudProvider.SENDER, CloudProvider.TEXT };
	public int[] to = new int[] { R.id.cart_row_sender, R.id.cart_row_message };
	String clientId;
    Cursor cursor = null;
    AckReceiver receiver;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);

		Intent myIntent = getIntent();
		clientId = myIntent.getStringExtra(constant.CLIENT_ID);
		msgList = (ListView) findViewById(R.id.msgList);
		msgTxt = (EditText) findViewById(R.id.message_text);

        cr = getContentResolver();
        cursor = cr.query(CloudProvider.CONTENT_URI, null, null, null, null);
		msgAdapter = new SimpleCursorAdapter(this, android.R.layout.simple_list_item_2, null, new String[] {"sender", "text" }, new int[] { android.R.id.text1, android.R.id.text2 });
		msgList.setAdapter(msgAdapter);
		msgAdapter.changeCursor(cursor);

		SharedPreferences prefs = this.getSharedPreferences(constant.SHARED_PREF,Context.MODE_PRIVATE);
		uuidStr = prefs.getString(constant.CLIENT_UUID,"00000000-8888-1111-a5e2-0800201c9a66");
		clientName = prefs.getString(constant.NAME, "DefaultClient");
		portNo = prefs.getString(constant.PORT, "8080");
		hostStr = prefs.getString(constant.HOST, "localhost");

        receiver = new AckReceiver(new Handler());

		Resources res = getResources();
		send = (Button) findViewById(R.id.send_button);
		send.setOnClickListener(sendListener);

		Long time = (long) (3*1000); //(3 * 1000)
		Intent intentAlarm = new Intent(this, AlarmReceiver.class);
        intentAlarm.putExtra(constant.RECEIVER, receiver);
		PendingIntent sender = 	PendingIntent.getBroadcast(this, 12, intentAlarm, 0);
		intentAlarm.putExtra(constant.CLIENT_ID, clientId);
		alarmManager = (AlarmManager) getSystemService(Context.ALARM_SERVICE);

		// set the alarm for particular time
		alarmManager.setRepeating(AlarmManager.ELAPSED_REALTIME_WAKEUP, SystemClock.elapsedRealtime(), time, sender);
		Toast.makeText(this, "Syncing server", Toast.LENGTH_SHORT).show();
        msgAdapter.changeCursor(cursor);
	}

	private OnClickListener sendListener = new OnClickListener() {
		public void onClick(View v) {
			ContentValues cv = new ContentValues();
			ChatMessage cm = new ChatMessage(0, msgTxt.getText().toString(), clientName, 0, new Date().getTime());
			cm.writeToProvider(cv);
			try {
				getContentResolver().insert(CloudProvider.CONTENT_URI, cv);
			} catch (Exception e) {
				e.printStackTrace();
			}
			Cursor cursor = cr.query(CloudProvider.CONTENT_URI, null, null, null, null);
			msgAdapter.changeCursor(cursor);
		};
	};

    public class AckReceiver extends ResultReceiver {
        public AckReceiver(Handler handler) {
            super(handler);
            // TODO Auto-generated constructor stub
        }

        protected void onReceiveResult(int resultCode, Bundle result) {
            switch (resultCode) {
                case 3:
                    //msgAdapter.notifyDataSetChanged();
                    cursor.requery();
                    msgAdapter.changeCursor(cursor);
                    Log.i(TAG, "OnReceiveResult case 3: Refresh Loader Managers");
                    break;
                default:
                    break;
            }
        }
    };

	@Override
	public void onStop(){
        super.onStop();
        Intent intentAlarm = new Intent(this, AlarmReceiver.class);
        alarmManager = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
		PendingIntent sender = 	PendingIntent.getBroadcast(this, 12, intentAlarm,0);
		 try {
             alarmManager.cancel(sender);
         } catch (Exception e) {
             Log.e(TAG, "AlarmManager update was not cancelled. " + e.toString());
         }
	}
	@Override
	public void onDestroy(){
        super.onDestroy();
		Intent intentAlarm = new Intent(this, AlarmReceiver.class);
		alarmManager = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
		PendingIntent sender = 	PendingIntent.getBroadcast(this, 12, intentAlarm,0);
		 try {
             alarmManager.cancel(sender);
         }catch (Exception e) {
             Log.e(TAG, "AlarmManager update was not canceled. " + e.toString());
         }
		 cr.delete(CloudProvider.CONTENT_URI, null, null);
         cr.delete(CloudProvider.CONTENT_URI_PEER, null, null);
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		super.onCreateOptionsMenu(menu);
		this.getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		super.onOptionsItemSelected(item);
		switch (item.getItemId()) {
            case (R.id.show_peers):
			    Intent peersIntent = new Intent(this, PeersActivity.class);
                startActivityForResult(peersIntent, 2);
			    return true;
            case(R.id.show_settings):
                Intent settingsIntent = new Intent(this,startActivity.class);
                startActivityForResult(settingsIntent,2);
                return true;
		}
		return false;
	}

	public Loader<Cursor> onCreateLoader(int arg0, Bundle arg1) {

		return new CursorLoader(this, CloudProvider.CONTENT_URI,
				CloudProvider.MessageProjection, null, null, null);
	}

	public void onLoadFinished(Loader<Cursor> loader, Cursor cursor) {
		this.msgAdapter.swapCursor(cursor);

	}

	public void onLoaderReset(Loader<Cursor> loader) {
		this.msgAdapter.swapCursor(null);
	}

}
