package cs522.stevens.mehulgupta.com.mehulguptasfirstapp;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class StartPage extends AppCompatActivity {

    public final static String MESSAGE = "com.mehulgupta.stevens.cs522.firstapp.MESSAGE";
    String userNameStr, passwordStr;
    Intent startLoggedActivityIntent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_start_page);

        startLoggedActivityIntent = new Intent(this, DisplayMessageActivity.class);

        Button submit = (Button)findViewById(R.id.buttonSubmit);
        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sendMessage();
            }
        });
    }

    protected void sendMessage(){
        EditText userNameTextView = (EditText)findViewById(R.id.editTextUserName);
        userNameStr = userNameTextView.getText().toString();
        EditText passwordTextView = (EditText)findViewById(R.id.editTextPassword);
        passwordStr = passwordTextView.getText().toString();

        Log.d("First App", "onCreate: UserName = " + userNameStr);
        Bundle bundle = new Bundle();
        bundle.putString(MESSAGE, userNameStr);
        startLoggedActivityIntent.putExtras(bundle);

        startActivity(startLoggedActivityIntent);
    }

}
