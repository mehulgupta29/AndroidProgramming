package cs522.stevens.mehulgupta.com.mehulguptasfirstapp;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class DisplayMessageActivity extends AppCompatActivity {

    public final static String MESSAGE = "com.mehulgupta.stevens.cs522.firstapp.MESSAGE";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_display_message);

        Bundle bundle = getIntent().getExtras();
        TextView displayUserName = (TextView)findViewById(R.id.textViewDisplayUserName);
        displayUserName.setText(bundle.getString(MESSAGE));
    }
}
