package edu.stevens.cs522.chat.oneway.client.activities;

/**
 * Created by DV6 on 2/13/2016.
 */
public class constants {

    public static final String saveClientNamePreferences = "SAVE_CLIENT_NAME_PREFERENCES";
}
