package edu.stevens.cs522.chat.activities;

import edu.stevens.cs522.chat.contracts.MessageContract;
import edu.stevens.cs522.chat.contracts.PeerContract;
import edu.stevens.cs522.chat.entities.Peer;
import edu.stevens.cs522.chat.managers.IContinue;
import edu.stevens.cs522.chat.managers.IEntityCreator;
import edu.stevens.cs522.chat.managers.PeerManager;
import android.app.ListActivity;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.SimpleCursorAdapter;
import android.widget.TextView;

public class PeerDetail extends ListActivity {
	
	private SimpleCursorAdapter simpleCursorAdapter;
	private PeerManager peerManager;
	private static final int MESSAGES_LOADER_ID = 2;
	private TextView ipAddressTV;
	private TextView portNumberTV;
	
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.detail_list);
		populateData(null);

        Intent intentPeer = getIntent();
        long id = intentPeer.getLongExtra(constants.PEER_LISTS_ID,-1);
        
        peerManager = new PeerManager(this, new IEntityCreator<Peer>() {

			public Peer create(Cursor cursor) {
				return new Peer(cursor);
			}
		}, MESSAGES_LOADER_ID);

		peerManager.getAllAsync(PeerContract.MESSAGE_CONTENT_URI, 
								new String[]{PeerContract.PEER_ID,MessageContract.MESSAGE_MESSAGE}, 
								MessageContract.MESSAGE_PEER_FK + "=?", 
								new String[]{String.valueOf(id)}, 
								null, 
								new IContinue<Cursor>() {
			
					public void kontinue(Cursor value) {
						simpleCursorAdapter.swapCursor(value);
					}
		});
		
		Uri peerUri = PeerContract.withExtendedPath(PeerContract.CONTENT_URI, String.valueOf(id));
		
		peerManager.getAllAsync(peerUri, 
								new String[]{PeerContract.PEER_ADDRESS, PeerContract.PEER_ADDRESS_PORT}, 
								null, 
								null, 
								null, 
								new IContinue<Cursor>() {

					public void kontinue(Cursor value) {

						value.moveToFirst();
						byte[] blob = value.getBlob(value.getColumnIndex(PeerContract.PEER_ADDRESS));
						String address = new String(blob);
						int port = value.getInt(value.getColumnIndexOrThrow(PeerContract.PEER_ADDRESS_PORT));
						ipAddressTV.setText(address);
						portNumberTV.setText(String.valueOf(port));
					}
		});
		
	}
	
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		super.onCreateOptionsMenu(menu);
		getMenuInflater().inflate(R.menu.peer_details_menu, menu);
		return true;
	}
	
	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		super.onOptionsItemSelected(item);
		return false;
	}

    private void populateData(Cursor cr){
        String[] from = new String[]{MessageContract.MESSAGE_MESSAGE};
        int[] to = new int[]{R.id.detail_list_row_msg};
        this.ipAddressTV = (TextView)findViewById(R.id.ip_address);
        this.portNumberTV = (TextView)findViewById(R.id.port_number);
        simpleCursorAdapter = new SimpleCursorAdapter(this, R.layout.detail_list_row, cr, from, to, 0);
        setListAdapter(simpleCursorAdapter);
        this.setSelection(0);
    }

}
