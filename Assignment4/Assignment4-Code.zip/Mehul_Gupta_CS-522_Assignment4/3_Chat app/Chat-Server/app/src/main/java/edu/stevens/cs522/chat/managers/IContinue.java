package edu.stevens.cs522.chat.managers;

public interface IContinue<T> {

	public void	kontinue(T value);
	
}
