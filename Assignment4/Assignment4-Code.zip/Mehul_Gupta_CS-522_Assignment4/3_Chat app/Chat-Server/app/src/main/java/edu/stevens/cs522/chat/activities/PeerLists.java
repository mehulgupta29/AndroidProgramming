package edu.stevens.cs522.chat.activities;


import edu.stevens.cs522.chat.contracts.PeerContract;
import edu.stevens.cs522.chat.entities.Peer;
import edu.stevens.cs522.chat.managers.IEntityCreator;
import edu.stevens.cs522.chat.managers.PeerManager;
import edu.stevens.cs522.chat.managers.IContinue;
import android.app.ListActivity;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.ListView;
import android.widget.SimpleCursorAdapter;
import android.widget.Toast;

public class PeerLists extends ListActivity {

	static final private int PEER_DETAIL = 1;
	private SimpleCursorAdapter simpleAdapter;
	private long selected_item_pos = -1;
	private PeerManager peerManager;
	private static final int PEERS_LOADER_ID = 1;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.peer_list);
		populateDataInList(null);
		peerManager = new PeerManager(this, new IEntityCreator<Peer>() {

			public Peer create(Cursor cursor) {
				return new Peer(cursor);
			}
		}, PEERS_LOADER_ID);

		peerManager.getAllAsync(PeerContract.CONTENT_URI,new String[]{PeerContract.PEER_ID, PeerContract.PEER_NAME},null, null, null,
                new IContinue<Cursor>() {
			
			public void kontinue(Cursor value) {
				simpleAdapter.swapCursor(value);			
			}
		});
	}
	
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		super.onCreateOptionsMenu(menu);
		getMenuInflater().inflate(R.menu.peers_list_menu, menu);
		return true;
	}
	
	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		super.onOptionsItemSelected(item);
		return false;
	}
	
	@Override
	protected void onListItemClick(ListView list, View view, int position, long id) {
	    super.onListItemClick(list, view, position, id);
        this.selected_item_pos = id;
        Intent detailIntent = new Intent(this, PeerDetail.class);
        detailIntent.putExtra(constants.PEER_LISTS_ID, this.selected_item_pos);
        startActivityForResult(detailIntent, PEER_DETAIL);
	}

    private void populateDataInList(Cursor cr){
        String[] from = new String[]{PeerContract.PEER_NAME};
        int[] to = new int[]{R.id.peer_list_row_name};
        simpleAdapter = new SimpleCursorAdapter(this, R.layout.peer_list_row, cr, from, to, 0);
        setListAdapter(simpleAdapter);
        this.setSelection(0);
    }
}
