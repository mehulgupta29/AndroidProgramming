package edu.stevens.cs522.chat.activities;

/**
 * Created by DV6 on 2/21/2016.
 */
public class constants {

    public final static String PEER_LISTS_ID = "edu.stevens.cs522.chat.activities.EXTRA_PEER_ID";
}
