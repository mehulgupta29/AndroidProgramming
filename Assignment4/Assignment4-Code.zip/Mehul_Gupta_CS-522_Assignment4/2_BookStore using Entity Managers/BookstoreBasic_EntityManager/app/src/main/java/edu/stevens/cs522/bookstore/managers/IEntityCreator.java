package edu.stevens.cs522.bookstore.managers;

import android.database.Cursor;

/**
 * Created by DV6 on 2/20/2016.
 */
public interface IEntityCreator<T> {

    public T create(Cursor cursor);

}

