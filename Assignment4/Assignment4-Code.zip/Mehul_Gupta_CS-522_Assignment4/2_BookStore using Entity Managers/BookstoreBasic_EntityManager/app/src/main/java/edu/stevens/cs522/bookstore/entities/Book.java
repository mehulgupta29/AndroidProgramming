package edu.stevens.cs522.bookstore.entities;

import android.content.ContentValues;
import android.database.Cursor;
import android.os.Parcel;
import android.os.Parcelable;
import android.util.Log;

import java.util.regex.Pattern;

import edu.stevens.cs522.bookstore.contracts.BookContract;

public class Book implements Parcelable {

    public int id;
    public String title;
    public Author[] authors;
    public String isbn;
    public String price;

    public Book(Cursor cursor){
        this.id = Integer.parseInt(BookContract.getbId(cursor));
        this.title = BookContract.getTitle(cursor);
        this.authors = generateAuthors(cursor);
        this.isbn = BookContract.getIsbn(cursor);
        this.price = BookContract.getPrice(cursor);
    }

    public void writeToProvider(ContentValues contentValues){
        BookContract.putTitle(contentValues, this.title);
        BookContract.putAuthors(contentValues, this.authors[0].toString());
        BookContract.putIsbn(contentValues, this.isbn);
        BookContract.putPrice(contentValues, this.price);
    }

    public Book(String title, Author[] author, String isbn, String price) {
        this.title = title;
        this.authors = author;
        this.isbn = isbn;
        this.price = price;
    }

    public Book(int id, String title, Author[] author, String isbn, String price) {
        this.id = id;
        this.title = title;
        this.authors = author;
        this.isbn = isbn;
        this.price = price;
    }
    public String toString(){
        return this.title+" $"+ this.price;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeInt(this.id);
        dest.writeString(this.title);
        dest.writeTypedArray(this.authors, flags);
        dest.writeString(this.isbn);
        dest.writeString(this.price);
    }

    protected Book(Parcel in) {
        this.id = in.readInt();
        this.title = in.readString();
        this.authors = in.createTypedArray(Author.CREATOR);
        this.isbn = in.readString();
        this.price = in.readString();
    }

    public static final Creator<Book> CREATOR = new Creator<Book>() {
        public Book createFromParcel(Parcel source) {
            return new Book(source);
        }
        public Book[] newArray(int size) {
            return new Book[size];
        }
    };


    public static final char SEPARATOR_CHAR = ',';
    private static final Pattern SEPARATOR =   Pattern.compile(Character.toString(SEPARATOR_CHAR), Pattern.LITERAL);
    public static String[] readStringArray(String in) {   return SEPARATOR.split(in);}

    public Author[] generateAuthors(Cursor cursor){
        String [] authorArray = readStringArray(BookContract.getAuthors(cursor));
        Log.i("BOOK", Integer.toString(authorArray.length));
        Author[] authors = Author.CREATOR.newArray(authorArray.length);
        int index = 0;
        for(String author : authorArray){
            Author a = null;
            String [] authorFullName = author.split("\\s+");
            Log.i("BOOK", Integer.toString(authorFullName.length));
            if(authorFullName.length == 1){
                a = new Author(authorFullName[0]);
            }else if(authorFullName.length == 2){
                a = new Author(authorFullName[0], authorFullName[1]);
            }else if(authorFullName.length == 3){
                a = new Author(authorFullName[0], authorFullName[1], authorFullName[2]);
            }else{
                Log.i("Array_Book.java", "Error in authors");
            }
            authors[index] = a;
            //Log.i("BOOK", "Author list = "+authors[index].firstName+" "+authors[index].lastName);
            index++;
        }
        return authors;
    }

    public int getId() {
        return id;
    }

    public String getTitle() {
        return title;
    }

    public Author[] getAuthors() {
        return authors;
    }

    public String getIsbn() {
        return isbn;
    }

    public String getPrice() {
        return price;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public void setAuthors(Author[] authors) {
        this.authors = authors;
    }

    public void setIsbn(String isbn) {
        this.isbn = isbn;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public String getAutherName() {
        StringBuilder authList = new StringBuilder();
        authList.append(authors[0].firstName);
        authList.append(authors[0].middleName);
        authList.append(authors[0].lastName);
        return authList.toString();
    }
}