package edu.stevens.cs522.bookstore.activities;


import android.app.Activity;
import android.app.LoaderManager;
import android.content.CursorLoader;
import android.content.Intent;
import android.content.Loader;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;

import java.util.regex.Pattern;

import edu.stevens.cs522.bookstore.R;
import edu.stevens.cs522.bookstore.contracts.BookContract;
import edu.stevens.cs522.bookstore.entities.Author;
import edu.stevens.cs522.bookstore.entities.Book;


public class DetailsActivity extends Activity implements LoaderManager.LoaderCallbacks<Cursor> {

    private static final String BOOK_DETAILS = "Book_Details";
    private TextView titleTV, authorsTV, priceTV, isbnTV;
    private TextView passedView = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.search_results);
        LoaderManager lm=getLoaderManager();
        lm.initLoader(0, null, this);
    }


    public static final char SEPARATOR_CHAR = '|';
    private static final Pattern SEPARATOR =   Pattern.compile(Character.toString(SEPARATOR_CHAR), Pattern.LITERAL);
    public static String[] readStringArray(String in) {   return SEPARATOR.split(in);}

    public Author[] generateAuthors(String authorEV){
        String [] authorArray = readStringArray(authorEV); //authorEV.split(",");
        Author[] authors = Author.CREATOR.newArray(authorArray.length);
        int index = 0;
        for(String author : authorArray){
            Author a = null;
            String [] authorFullName = author.split("\\s+");
            if(authorFullName.length == 1){
                a = new Author(authorFullName[0]);
            }else if(authorFullName.length == 2){
                a = new Author(authorFullName[0], authorFullName[1]);
            }else if(authorFullName.length == 3){
                a = new Author(authorFullName[0], authorFullName[1], authorFullName[2]);
            }else{
                Log.i("Array_DetailsActivity", "Error in authors");
            }
            authors[index] = a;
            Log.i(constants.Detail, "DetailsActivity: Author List="+authors[index].firstName+" "+authors[index].lastName);
            index++;
        }

        return authors;
    }


    @Override
    public Loader<Cursor> onCreateLoader(int i, Bundle bundle) {
        switch(i)
        {
            case 0:
                Intent intent = getIntent();
                long id = intent.getLongExtra("Detail",0);
                Uri ui = BookContract.B_CONTENT_URI(id);
                return new CursorLoader(this,ui,null,null,null,null);
            default:
                return null;
        }
    }

    @Override
    public void onLoadFinished(Loader<Cursor> cursorLoader, Cursor cursor) {
        if(cursor != null) {
            cursor.moveToFirst();
            String x = "";
            x = x + "Title : " + BookContract.getTitle(cursor) + '\n' + '\n' +
                    "Author : " + BookContract.getAuthors(cursor) + '\n' + '\n' +
                    "ISBN : " + BookContract.getIsbn(cursor) + '\n' + '\n' +
                    "Price : $" + BookContract.getPrice(cursor);
            passedView = (TextView) findViewById(R.id.passedView);
            passedView.setText(x);
        }else{
            Log.i("Details", "cursor is null");
        }
    }

    @Override
    public void onLoaderReset(Loader<Cursor> cursorLoader) {

    }

}
