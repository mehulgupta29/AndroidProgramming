package edu.stevens.cs522.bookstore.databases;

import android.content.Context;
import android.database.Cursor;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ResourceCursorAdapter;
import android.widget.TextView;

import edu.stevens.cs522.bookstore.R;
import edu.stevens.cs522.bookstore.contracts.BookContract;

/**
 * Created by DV6 on 2/21/2016.
 */
public class BookAdapter extends ResourceCursorAdapter  {
    protected final static int ROW_LAYOUT = R.layout.cart_row;

    public BookAdapter(Context context, Cursor cursor) {
        super(context, ROW_LAYOUT, cursor, 0);
    }

    @Override
    public View newView(Context context, Cursor cur, ViewGroup parent) {
        LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        return inflater.inflate(ROW_LAYOUT, parent, false);
    }

    @Override
    public void bindView(View view, Context context, Cursor cursor) {
        TextView txtTitle = (TextView) view.findViewById(R.id.cart_row_title);
        txtTitle.setText(BookContract.getTitle(cursor));

        TextView txtAuthors = (TextView) view.findViewById(R.id.cart_row_author);
        txtAuthors.setText(BookContract.getAuthors(cursor));

        TextView txtIsbn = (TextView) view.findViewById(R.id.cart_row_isbn);
        txtIsbn.setText(BookContract.getIsbn(cursor));

        TextView txtPrice = (TextView) view.findViewById(R.id.cart_row_price);
        txtPrice.setText(BookContract.getPrice(cursor));

    }
}