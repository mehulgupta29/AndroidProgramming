package edu.stevens.cs522.bookstore.providers;

import android.content.ContentProvider;
import android.content.ContentUris;
import android.content.ContentValues;
import android.content.Context;
import android.content.UriMatcher;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.database.sqlite.SQLiteQueryBuilder;
import android.net.Uri;
import android.support.annotation.Nullable;
import android.text.TextUtils;
import android.util.Log;
import android.widget.Toast;

import java.util.HashMap;

import edu.stevens.cs522.bookstore.contracts.BookContract;
import edu.stevens.cs522.bookstore.contracts.BookContract;
import edu.stevens.cs522.bookstore.databases.CartDbAdapter;

/**
 * Created by DV6 on 2/18/2016.
 */
public class BookProvider extends ContentProvider {

    private static final String DATABASE_NAME = "book.db";
    private static final int DATABASE_VERSION = 8;


    private static final String VIEW_BOOK="book_author_view";

    private static final String DATABASE_CREATE_BOOK_TABLE ="CREATE TABLE "+BookContract.BOOK_TABLE+" ("+
            BookContract.B_ID +" integer primary key autoincrement,"+
            BookContract.TITLE+" text,"+
            BookContract.AUTHOR+" text,"+
            BookContract.ISBN+" text,"+
            BookContract.PRICE+" text);";

    private static final String DATABASE_CREATE_AUTHOR_TABLE ="CREATE TABLE "+BookContract.AUTHOR_TABLE+" ("+
            BookContract.A_ID +" integer primary key autoincrement,"+
            BookContract.FIRST_NAME+" text,"+
            BookContract.MIDDLE_NAME +" text,"+
            BookContract.LAST_NAME+" text,"+
            BookContract.BOOK_FK+" integer not null, foreign key ("+BookContract.BOOK_FK+") references "+BookContract.BOOK_TABLE+"("+ BookContract.B_ID +")on delete cascade );";


    public static final String CREATE_INDEX="Create index AuthorsBookIndex on "+BookContract.AUTHOR_TABLE+"("+ BookContract.BOOK_FK+");";

    public static final String BOOK_AUTHOR_JOIN_DETAIL = "SELECT "+
            BookContract.BOOK_TABLE+"."+BookContract.B_ID+", "+
            BookContract.TITLE+
            ", GROUP_CONCAT("+BookContract.FIRST_NAME+"||' '||COALESCE("+BookContract.MIDDLE_NAME+",'-')||' '||"+BookContract.LAST_NAME+" , '|') as "+BookContract.AUTHOR+ ", "+
            BookContract.ISBN+", "+
            BookContract.PRICE+" FROM "+
            BookContract.BOOK_TABLE+" LEFT OUTER JOIN "+BookContract.AUTHOR_TABLE+" ON "+
            BookContract.BOOK_TABLE+"."+BookContract.B_ID+" = "+BookContract.AUTHOR_TABLE+"."+BookContract.BOOK_FK+" GROUP BY "+
            BookContract.BOOK_TABLE+"."+BookContract.B_ID;

    public static String row_id = "select last_insert_rowid() from "+BookContract.BOOK_TABLE;

    private static HashMap<String, String> BOOKS_PROJECTION_MAP;
    private SQLiteDatabase sqlDB;
    private DatabaseHelper dbHelper;

    public static final int ALL_ROWS = 1;
    public static final int SINGLE_ROWS = 2;
    private final static UriMatcher urimatcher;
    static{
        urimatcher = new UriMatcher(UriMatcher.NO_MATCH);
        urimatcher.addURI(BookContract.AUTHORITY,BookContract.BOOK_TABLE+"/", ALL_ROWS);
        urimatcher.addURI(BookContract.AUTHORITY,BookContract.BOOK_TABLE+"/#", SINGLE_ROWS);
        urimatcher.addURI(BookContract.AUTHORITY,BookContract.AUTHOR_TABLE+"/", ALL_ROWS);
        urimatcher.addURI(BookContract.AUTHORITY,BookContract.AUTHOR_TABLE+"/#", SINGLE_ROWS);
    }


    @Override
    public boolean onCreate() {
        //TODO construct the underlying database
        dbHelper = new DatabaseHelper(getContext());
        sqlDB = dbHelper.getWritableDatabase();
        if(sqlDB!=null)
            return true;
        else
            return false;
    }

    @Nullable
    @Override
    public Cursor query(Uri uri, String[] projection, String selection, String[] selectionArgs, String sortOrder) {
        SQLiteQueryBuilder queryBuilder = new SQLiteQueryBuilder();
        switch (urimatcher.match(uri)) {
            case ALL_ROWS:
                queryBuilder.setTables(BookContract.BOOK_TABLE + "," + BookContract.AUTHOR_TABLE);
                queryBuilder.appendWhere(BookContract.BOOK_TABLE + "." + BookContract.B_ID + " = "+BookContract.AUTHOR_TABLE + "." + BookContract.BOOK_FK);
                queryBuilder.setProjectionMap(BOOKS_PROJECTION_MAP);
                break;
            case SINGLE_ROWS:
                queryBuilder.setTables(BookContract.BOOK_TABLE);
                queryBuilder.appendWhere(BookContract.B_ID + "=" + uri.getPathSegments().get(1));
                Cursor cu = sqlDB.rawQuery(BOOK_AUTHOR_JOIN_DETAIL, null);
                return cu;
            default:
                throw new IllegalArgumentException("Unknown URI " + uri);
        }
        if (sortOrder == null || sortOrder == "") {
            sortOrder = BookContract.BOOK_TABLE+"."+BookContract.B_ID;
        }

        Cursor cursor = queryBuilder.query(sqlDB, projection, selection, selectionArgs, null,null, sortOrder);
        cursor.moveToFirst();
        cursor.setNotificationUri(getContext().getContentResolver(), uri);
        return cursor;
    }

    @Nullable
    @Override
    public String getType(Uri uri) {
        switch(urimatcher.match(uri)){
            case ALL_ROWS:
                if (uri == BookContract.B_CONTENT_URI) {
                    return "vnd.android.cursor/vnd.edu.stevens.cs522.bookstore.books";
                } else
                    return "vnd.android.cursor/vnd.edu.stevens.cs522.bookstore.authors";
            case SINGLE_ROWS:
                if (uri == BookContract.B_CONTENT_URI) {
                    return "vnd.android.cursor/vnd.edu.stevens.cs522.bookstore.books";
                } else
                    return "vnd.android.cursor/vnd.edu.stevens.cs522.bookstore.authors";
            default:
                throw new IllegalArgumentException("Unsupported URI "+ uri);
        }
    }

    @Nullable
    @Override
    public Uri insert(Uri uri, ContentValues values) {
        Log.i("Book Provider:","URI insert: URI="+uri.toString());
        Uri _uri = null;
        if (uri.equals( BookContract.B_CONTENT_URI)) {
            Log.i("Book Provider:","in books");
            long rowID = sqlDB.insert(BookContract.BOOK_TABLE, null, values);
            if (rowID > 0){
                Log.i("Book Provider:","rowId > 0");
                _uri = ContentUris.withAppendedId(BookContract.B_CONTENT_URI,rowID);
                getContext().getContentResolver().notifyChange(_uri , null);
                return _uri;
            }
        }else if (uri.equals( BookContract.A_CONTENT_URI)) {
            long rowID = sqlDB.insert(BookContract.AUTHOR_TABLE, null, values);
            if (rowID > 0){
                Log.i("Book Provider:","Author_rowId > 0");
                _uri = ContentUris.withAppendedId(BookContract.A_CONTENT_URI, rowID);
                getContext().getContentResolver().notifyChange(_uri , null);
                return _uri;
            }
        }else
            Toast.makeText(getContext(), "Row Insert Failed", Toast.LENGTH_LONG).show();
        return null;
    }

    @Override
    public int delete(Uri uri, String selection, String[] selectionArgs) {
        int rowsDeleted = 0;
        switch (urimatcher.match(uri)){
            case ALL_ROWS:
                sqlDB.delete(BookContract.AUTHOR_TABLE, selection, selectionArgs);
                rowsDeleted = sqlDB.delete(BookContract.BOOK_TABLE, selection, selectionArgs);
                getContext().getContentResolver().notifyChange(uri, null);
                break;

            case SINGLE_ROWS:
                long rowId = BookContract.getUriId(uri);
                String where = BookContract.BOOK_FK+"="+rowId;
                String whereArgs= BookContract.B_ID+"="+rowId;
                sqlDB.delete(BookContract.AUTHOR_TABLE, where, null);
                rowsDeleted = sqlDB.delete(BookContract.BOOK_TABLE,whereArgs,null);
                getContext().getContentResolver().notifyChange(uri, null);
                break;

            default:
                throw new IllegalArgumentException("Unsupported URI" +uri);
        }
        return rowsDeleted;
    }

    @Override
    public int update(Uri uri, ContentValues values, String selection, String[] selectionArgs) {
        int rowsUpdated = 0;

        switch (urimatcher.match(uri)){
            case ALL_ROWS:
                rowsUpdated = sqlDB.update(BookContract.BOOK_TABLE,values,selection,selectionArgs);
                break;

            case SINGLE_ROWS:
                rowsUpdated = sqlDB.update(BookContract.BOOK_TABLE, values, BookContract.B_ID + " = "+ uri.getPathSegments().get(1)+(!TextUtils.isEmpty
                        (selection)? " AND ("+ selection + ')' : ""), selectionArgs);
                break;

            default:
                throw new IllegalArgumentException("Unsupported URI" +uri);
        }
        getContext().getContentResolver().notifyChange(uri,null);
        return rowsUpdated;
    }

    private static class DatabaseHelper extends SQLiteOpenHelper {

        DatabaseHelper(Context context){
            super(context,DATABASE_NAME,null,DATABASE_VERSION);
        }

        @Override
        public void onCreate(SQLiteDatabase database) {
            database.execSQL(DATABASE_CREATE_BOOK_TABLE);
            database.execSQL(DATABASE_CREATE_AUTHOR_TABLE);
            database.execSQL(CREATE_INDEX);

        }

        @Override
        public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i2) {

            Log.w(DatabaseHelper.class.getName(),
                    "Upgrading database from version " + i + " to "
                            + i2 + ", which will destroy all old data");
            sqLiteDatabase.execSQL("DROP TABLE IF EXISTS "+BookContract.BOOK_TABLE);
            sqLiteDatabase.execSQL("DROP TABLE IF EXISTS "+BookContract.AUTHOR_TABLE);
            //  sqLiteDatabase.execSQL("DROP VIEW IF EXISTS "+VIEW_BOOK);
            onCreate(sqLiteDatabase);

        }
    }
}
