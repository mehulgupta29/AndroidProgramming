package edu.stevens.cs522.bookstore.managers;

import java.util.List;

import edu.stevens.cs522.bookstore.entities.Book;

/**
 * Created by DV6 on 2/20/2016.
 */
public interface ISimpleQueryListener<T> {

    public void handleResults(List<T> results);
}

