package edu.stevens.cs522.bookstore.contracts;

import android.content.ContentValues;
import android.database.Cursor;
import android.net.Uri;


/**
 * Created by DV6 on 2/7/2016.
 */
public class BookContract {
    public static final int B_ID_KEY = 0;
    public static final int TITLE_KEY = 1;
    public static final int AUTHOR_KEY = 2;
    public static final int ISBN_KEY = 3;
    public static final int PRICE_KEY = 4;

    public static final String B_ID = "_id";
    public static final String TITLE = "title";
    public static final String AUTHOR = "authors";
    public static final String ISBN = "isbn";
    public static final String PRICE = "price";

    public static final int A_ID_KEY = 0;
    public static final int FIRST_NAME_KEY = 1;
    public static final int MIDDLE_NAME_KEY = 2;
    public static final int LAST_NAME_KEY = 3;
    public static final int BOOK_FK_KEY = 4;

    public static final String A_ID = "_id";
    public static final String FIRST_NAME = "first_name";
    public static final String MIDDLE_NAME = "middle_name";
    public static final String LAST_NAME = "last_name";
    public static final String BOOK_FK = "foreign_key";


    public static final String AUTHORITY = "edu.stevens.cs522.bookstore";
    public static final String BOOK_TABLE = "books";
    public static final String AUTHOR_TABLE = "authors";
    public static final String B_CONTENT_PATH = "/"+BOOK_TABLE;
    public static final String A_CONTENT_PATH = "/"+AUTHOR_TABLE;

    public static final String B_URL = "content://"+AUTHORITY+B_CONTENT_PATH;
    public static Uri B_CONTENT_URI = Uri.parse(B_URL);
    public static Uri B_CONTENT_URI(long id){
        return Uri.parse("content://"+BookContract.AUTHORITY+BookContract.B_CONTENT_PATH+"/"+id);
    }

    public static String A_URL = "content://"+AUTHORITY+A_CONTENT_PATH;
    public static Uri A_CONTENT_URI = Uri.parse(A_URL);
    public static Uri A_CONTENT_URI(long id){
        return Uri.parse("content://"+BookContract.AUTHORITY+BookContract.A_CONTENT_PATH+"/"+id);
    }

    public static long getUriId(Uri uri){
        return Long.parseLong(uri.getLastPathSegment());
    }

    public static String getbId(Cursor cursor){
        return cursor.getString(cursor.getColumnIndexOrThrow(B_ID));
    }
    public static void putId(ContentValues contentValues, String id){
        contentValues.put(B_ID, id);
    }
    public static String getTitle(Cursor cursor){
        return cursor.getString(cursor.getColumnIndexOrThrow(TITLE));
    }
    public static void putTitle(ContentValues contentValues, String title){
        contentValues.put(TITLE, title);
    }
    public static String getAuthors(Cursor cursor){
        return cursor.getString(cursor.getColumnIndexOrThrow(AUTHOR));
    }
    public static void putAuthors(ContentValues contentValues, String authors) {
        contentValues.put(AUTHOR, authors);
    }
    public static String getIsbn(Cursor cursor){
        return cursor.getString(cursor.getColumnIndexOrThrow(ISBN));
    }
    public static void putIsbn(ContentValues contentValues, String isbn){
        contentValues.put(ISBN, isbn);
    }
    public static String getPrice(Cursor cursor){
        return cursor.getString(cursor.getColumnIndexOrThrow(PRICE));
    }
    public static void putPrice(ContentValues contentValues, String price){
        contentValues.put(PRICE, price);
    }

    public static String getaId(Cursor cursor){
        return cursor.getString(cursor.getColumnIndexOrThrow(A_ID));
    }
    public static void putaId(ContentValues contentValues, String author_id){
        contentValues.put(A_ID, author_id);
    }
    public static String getFirstName(Cursor cursor){
        return cursor.getString(cursor.getColumnIndexOrThrow(FIRST_NAME));
    }
    public static void putFirstName(ContentValues contentValues, String first_name){
        contentValues.put(FIRST_NAME, first_name);
    }
    public static String getMiddleName(Cursor cursor){
        return cursor.getString(cursor.getColumnIndexOrThrow(MIDDLE_NAME));
    }
    public static void putMiddleName(ContentValues contentValues, String middle_name){
        contentValues.put(MIDDLE_NAME, middle_name);
    }
    public static String getLastName(Cursor cursor){
        return cursor.getString(cursor.getColumnIndexOrThrow(LAST_NAME));
    }
    public static void putLastName(ContentValues contentValues, String last_name){
        contentValues.put(LAST_NAME, last_name);
    }
    public static int getBookFk(Cursor cursor){
        return cursor.getInt(cursor.getColumnIndexOrThrow(BOOK_FK));
    }
    public static void putBookFk(ContentValues contentValues, int bookfk){
        contentValues.put(BOOK_FK, bookfk);
    }
}
