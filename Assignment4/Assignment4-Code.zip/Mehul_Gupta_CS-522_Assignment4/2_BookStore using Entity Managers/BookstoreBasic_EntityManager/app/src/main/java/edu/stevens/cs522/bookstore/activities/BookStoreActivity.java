package edu.stevens.cs522.bookstore.activities;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;

import android.app.Activity;
import android.app.LoaderManager;
import android.content.ContentResolver;
import android.content.CursorLoader;
import android.content.Intent;
import android.content.Loader;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.util.SparseBooleanArray;
import android.view.ActionMode;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import edu.stevens.cs522.bookstore.R;
import edu.stevens.cs522.bookstore.contracts.BookContract;
import edu.stevens.cs522.bookstore.databases.BookAdapter;
import edu.stevens.cs522.bookstore.entities.Book;
import edu.stevens.cs522.bookstore.managers.BookManager;
import edu.stevens.cs522.bookstore.managers.IEntityCreator;

public class BookStoreActivity extends Activity implements LoaderManager.LoaderCallbacks<Cursor> {
	
	// Use this when logging errors and warnings.
	@SuppressWarnings("unused")
	private static final String TAG = BookStoreActivity.class.getCanonicalName();
	
	// These are request codes for subactivity request calls
    static final private int ADD_REQUEST = 1;
    private static final int BOOK_LOADER_ID = 1;
    public static final int AUTH_LOADER_ID = 2;

    @SuppressWarnings("unused")
    static final private int CHECKOUT_REQUEST = ADD_REQUEST + 1;

	// There is a reason this must be an ArrayList instead of a List.
	@SuppressWarnings("unused")
	private ArrayList<Book> shoppingCart = new ArrayList<Book>();
    private ListView bookStoreListView;

   // private BookAdapter bookAdapter;
    ContentResolver resolver;

    LoaderManager lm = getLoaderManager();
    BookManager bm;
    private ArrayList<Integer> del = new ArrayList<Integer>();
    private static ArrayList<Integer> ref = new ArrayList<Integer>();
    int count;

    @Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

        // TODO check if there is saved UI state, and if so, restore it (i.e. the cart contents)
        resolver = getContentResolver();

        // TODO Set the layout (use cart.xml layout)
		setContentView(R.layout.cart);

        bm = new BookManager(this, new IEntityCreator<Book>() {
            @Override
            public Book create(Cursor cursor) {
                return new Book(cursor);
            }
        }, BOOK_LOADER_ID);

        // TODO use an array adapter to display the cart contents.
        bookStoreListView = (ListView)findViewById(android.R.id.list);
        lm.initLoader(BOOK_LOADER_ID, null, this);

        // For Contextual Action Menu
        bookStoreListView.setChoiceMode(ListView.CHOICE_MODE_MULTIPLE_MODAL);
        bookStoreListView.setMultiChoiceModeListener(new AbsListView.MultiChoiceModeListener() {
            @Override
            public void onItemCheckedStateChanged(ActionMode mode, int position, long id, boolean checked) {
                if(bookStoreListView.isItemChecked(position)) {
                    count = count + 1;
                    mode.setTitle(count + " book(s) selected");
                    del.add(position+1);
                }else
                {
                    count--;
                    mode.setTitle(count + " book(s) selected");
                    del.remove(position);
                }
            }

            @Override
            public boolean onCreateActionMode(ActionMode mode, Menu menu) {
                Log.i(TAG, "creating action mode");
                mode.getMenuInflater().inflate(R.menu.context_action_bar_menu, menu);
                return true;
            }

            @Override
            public boolean onPrepareActionMode(ActionMode mode, Menu menu) {
                return false;
            }

            @Override
            public boolean onActionItemClicked(ActionMode mode, MenuItem item) {
                switch (item.getItemId()) {
                    case R.id.cab_menu_delete:
                        try {
                            Log.i(TAG, "action item delete clicked");
                            deleteSelectedBooks();
                            Toast.makeText(getBaseContext(), "Record deleted", Toast.LENGTH_SHORT).show();
                            del.clear();
                            count = 0;
                            mode.finish();
                            return true;
                        } catch (Exception sqlE) {
                            sqlE.printStackTrace();
                        } finally {
                            return false;
                        }
                    default:
                        return false;
                }
            }

            @Override
            public void onDestroyActionMode(ActionMode mode) {
                Log.i(TAG, "destroying action mode");
                count = 0;
                del.clear();
            }
        });

        bookStoreListView.setOnItemClickListener(  new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Log.i("Details", "id= "+view.getId());
                Intent i = new Intent(BookStoreActivity.this, DetailsActivity.class);
                i.putExtra("POS",position+1);
                Log.i(TAG, "Details = "+id+" ,pos="+position);
                i.putExtra("Detail",id);
                startActivity(i);
            }
        });
        registerForContextMenu(bookStoreListView);
        bookStoreListView.setItemsCanFocus(true);
    }



    private void deleteSelectedBooks() throws SQLException{
        Log.i(TAG, "Delete");
        SparseBooleanArray checked = bookStoreListView.getCheckedItemPositions();

        for(int i = 0; i < checked.size(); i++){
            if(checked.valueAt(i) == true){
                    Uri ui=BookContract.B_CONTENT_URI(i);
                    ContentResolver cr = getContentResolver();
                    cr.delete(ui,null,null);
            }
        }
        Collections.sort(del);
        for(int i=del.size()-1;i>=0;i--)
        {
            int j=del.get(i);
            int index=ref.get(j-1);
            ref.remove(j-1);
            Uri ui=BookContract.B_CONTENT_URI(index);
            ContentResolver cr = getContentResolver();
            cr.delete(ui,null,null);
        }
        lm.restartLoader(BOOK_LOADER_ID, null, this);
    }

    @Override
    public Loader<Cursor> onCreateLoader(int i, Bundle bundle) {
        switch (i){
            case BOOK_LOADER_ID:
                return new CursorLoader(this, BookContract.B_CONTENT_URI, null
                        ,null, null, null);

            case AUTH_LOADER_ID:
                return new CursorLoader(this,BookContract.A_CONTENT_URI,null
                        ,null,null,null);
            default:
                return null;
        }
    }
    @Override
    public void onLoadFinished(Loader<Cursor> cursorLoader, Cursor cursor) {
        BookAdapter bd = new BookAdapter(this, cursor);
        int i= cursor.getCount();
        cursor.moveToFirst();
        ref.clear();
        for(int j=0;j<i;j++)
        {
            int m= Integer.parseInt(BookContract.getbId(cursor));
            ref.add(m);
            cursor.moveToNext();
        }
        bookStoreListView.setAdapter(bd);
    }
    @Override
    public void onLoaderReset(Loader<Cursor> cursorLoader) {
        BookAdapter bd = new BookAdapter(this, null);
        //bd.swapCursor(null);
        bd.changeCursor(null);
    }

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		super.onCreateOptionsMenu(menu);
		// TODO provide ADD, DELETE and CHECKOUT options
        getMenuInflater().inflate(R.menu.bookstore_menu, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		super.onOptionsItemSelected(item);
		// TODO

        switch(item.getItemId()){
            case android.R.id.home:
                finish();
                break;

            case R.id.add:  // ADD provide the UI for adding a ALL_ROWS
                Intent addIntent = new Intent(getApplicationContext(), AddBookActivity.class);
                startActivityForResult(addIntent, ADD_REQUEST);
                return true;

            case R.id.details:   // DELETE delete the currently selected ALL_ROWS

                return true;

            case R.id.checkout: // CHECKOUT provide the UI for checking out
                Intent checkOutIntent = new Intent(getApplicationContext(), CheckoutActivity.class);
                startActivityForResult(checkOutIntent, CHECKOUT_REQUEST);
                return true;
        }
	return false;
	}

    @Override
    protected void onActivityResult(int requestCode, int resultCode,
                                    Intent intent) {
        super.onActivityResult(requestCode, resultCode, intent);
        // TODO Handle results from the Search and Checkout activities.

        Book book;
        StringBuffer str = new StringBuffer();

        if(requestCode == ADD_REQUEST){
            if(resultCode == RESULT_OK){
                String actionBtn = (String)intent.getExtras().get(constants.button);
                if(actionBtn.equalsIgnoreCase("ADD")){  // ADD: add the ALL_ROWS that is returned to the shopping cart.
                    try{
                        lm.restartLoader(BOOK_LOADER_ID, null, this);
                        Toast.makeText(getApplicationContext(), "Book Added", Toast.LENGTH_SHORT).show();
                    }catch(Exception sqlE){
                        Toast.makeText(getApplicationContext(), "Book not added", Toast.LENGTH_SHORT).show();
                    }
                }else if(actionBtn.equalsIgnoreCase("SEARCH")){ // SEARCH: Search the ALL_ROWS in the shopping cart database: if found then show the ALL_ROWS details, else return back to Main activity
                    try{
                        lm.restartLoader(BOOK_LOADER_ID, null, this);
                        Toast.makeText(getApplicationContext(), "Book Added", Toast.LENGTH_SHORT).show();
                    }catch(Exception sqlE){
                        Toast.makeText(getApplicationContext(), "Book not searched", Toast.LENGTH_SHORT).show();
                    }
                }
            }else if(resultCode == RESULT_CANCELED){
                Toast.makeText(this,"AddBook Cancelled",Toast.LENGTH_SHORT).show();
            }
        }else if(requestCode == CHECKOUT_REQUEST){  // CHECKOUT: empty the shopping cart.
            if(resultCode == RESULT_OK){
                int rowsDeleted = getContentResolver().delete(BookContract.B_CONTENT_URI, null, null);
                lm.restartLoader(BOOK_LOADER_ID, null, this);
                Toast.makeText(this, Integer.toString(rowsDeleted)+" Books Checked Out", Toast.LENGTH_SHORT).show();
            }else if(resultCode == RESULT_CANCELED){
                Toast.makeText(this,"Checkout Cancelled",Toast.LENGTH_SHORT).show();
            }
        }
    }

    @Override
	public void onSaveInstanceState(Bundle savedInstanceState) {
		// TODO save the shopping cart contents (which should be a list of parcelables).
		savedInstanceState.putParcelableArrayList(constants.list, shoppingCart);
        super.onSaveInstanceState(savedInstanceState);
	}
}