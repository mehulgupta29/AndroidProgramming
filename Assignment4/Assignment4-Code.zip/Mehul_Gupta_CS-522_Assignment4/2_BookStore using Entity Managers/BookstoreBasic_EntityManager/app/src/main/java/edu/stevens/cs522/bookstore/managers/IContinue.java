package edu.stevens.cs522.bookstore.managers;

/**
 * Created by DV6 on 2/20/2016.
 */
public interface IContinue<T> {
    public void kontinue(T value);
}
