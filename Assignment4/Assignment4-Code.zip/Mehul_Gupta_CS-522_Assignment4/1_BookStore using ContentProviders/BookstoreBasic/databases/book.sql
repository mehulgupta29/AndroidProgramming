select * from book;
insert into book(title, authors, isbn, price) values('b53','ddp',53,53);
select * from author;
insert into author(first_name, middle_name, last_name, foreign_key) values('m','s','g',7);
insert into author(first_name, middle_name, last_name, foreign_key) values('a','s','p',8);
insert into author(first_name, middle_name, last_name, foreign_key) values('d','d','p',9);
insert into author(first_name, middle_name, last_name, foreign_key) values('m','s','g',9);

SELECT b._id, title, GROUP_CONCAT(first_name||middle_name||last_name, "|") as authors, price, isbn FROM book as b LEFT OUTER JOIN author as a ON b._id = a.foreign_key GROUP BY b._id, title, price, isbn;


--