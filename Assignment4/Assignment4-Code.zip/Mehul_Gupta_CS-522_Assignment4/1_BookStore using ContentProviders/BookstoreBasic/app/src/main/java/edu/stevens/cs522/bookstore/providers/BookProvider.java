package edu.stevens.cs522.bookstore.providers;

import android.content.ContentProvider;
import android.content.ContentUris;
import android.content.ContentValues;
import android.content.Context;
import android.content.UriMatcher;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.database.sqlite.SQLiteQueryBuilder;
import android.net.Uri;
import android.support.annotation.Nullable;
import android.text.TextUtils;
import android.util.Log;
import android.widget.Toast;

import java.util.HashMap;

import edu.stevens.cs522.bookstore.contracts.AuthorContract;
import edu.stevens.cs522.bookstore.contracts.BookContract;
import edu.stevens.cs522.bookstore.databases.CartDbAdapter;

/**
 * Created by DV6 on 2/18/2016.
 */
public class BookProvider extends ContentProvider {

    private static final String DATABASE_NAME = "book.db";
    private static final int DATABASE_VERSION = 6;

    //private static final String AUTHOR = "authors";

    private static final int ALL_ROWS = 1;
    private static final int SINGLE_ROWS = ALL_ROWS+1;

    private static final String VIEW_BOOK="book_author_view";

    private static final String DATABASE_CREATE_BOOK_TABLE ="create table "+BookContract.BOOK_TABLE+" ("+BookContract.ID +" integer primary key autoincrement,"+
            BookContract.TITLE+" text,"+BookContract.AUTHOR +" text,"+BookContract.ISBN+" text,"+BookContract.PRICE+" text);";

    private static final String DATABASE_CREATE_AUTHOR_TABLE ="create table "+AuthorContract.AUTHOR_TABLE+" ("+AuthorContract.ID +" integer primary key autoincrement,"+
            AuthorContract.FIRST_NAME+" text,"+AuthorContract.MIDDLE_NAME +" text,"+AuthorContract.LAST_NAME+" text,"+AuthorContract.BOOK_FK+
            " integer not null,foreign key ("+AuthorContract.BOOK_FK+") references "+BookContract.BOOK_TABLE+"("+ BookContract.ID +")on delete cascade );";


    public static String CREATE_INDEX="Create index AuthorsBookIndex on "+AuthorContract.AUTHOR_TABLE+"("+ AuthorContract.BOOK_FK+");";

    public static String row_id = "select last_insert_rowid() from "+BookContract.BOOK_TABLE;

    private static HashMap<String, String> BOOKS_PROJECTION_MAP;
    private SQLiteDatabase sqlDB;
    private DatabaseHelper dbHelper;
    private Context context;

    public CartDbAdapter cartDbAdapter;
    public static final int book = 1;
    public static final int book_id = 2;

    private final static UriMatcher urimatcher;
    static{
        urimatcher = new UriMatcher(UriMatcher.NO_MATCH);
        urimatcher.addURI(BookContract.AUTHORITY,BookContract.BOOK_TABLE+"/",book);
        urimatcher.addURI(BookContract.AUTHORITY,BookContract.BOOK_TABLE+"/#",book_id);
        urimatcher.addURI(BookContract.AUTHORITY,AuthorContract.AUTHOR_TABLE+"/", book);
        urimatcher.addURI(BookContract.AUTHORITY,AuthorContract.AUTHOR_TABLE+"/#", book_id);
    }


    @Override
    public boolean onCreate() {
        //TODO construct the underlying database
        dbHelper = new DatabaseHelper(getContext());
        sqlDB = dbHelper.getWritableDatabase();
        if(sqlDB!=null)
            return true;
        else
            return false;
    }

    @Nullable
    @Override
    public Cursor query(Uri uri, String[] projection, String selection, String[] selectionArgs, String sortOrder) {
        SQLiteQueryBuilder queryBuilder = new SQLiteQueryBuilder();

        switch (urimatcher.match(uri)) {
            case book:
                queryBuilder.setTables(BookContract.BOOK_TABLE + "," + AuthorContract.AUTHOR_TABLE);
                //  queryBuilder.setProjectionMap(BOOKS_PROJECTION_MAP);
                queryBuilder.appendWhere(BookContract.BOOK_TABLE + "." + BookContract.ID + "="+AuthorContract.AUTHOR_TABLE + "." + AuthorContract.BOOK_FK);
                queryBuilder.setProjectionMap(BOOKS_PROJECTION_MAP);
                break;
            case book_id:
                queryBuilder.setTables(BookContract.BOOK_TABLE);
                queryBuilder.appendWhere(BookContract.ID + "=" + uri.getPathSegments().get(1));
                break;
            default:
                throw new IllegalArgumentException("Unknown URI " + uri);
        }
        if (sortOrder == null || sortOrder == "") {
            sortOrder = "book." + BookContract.ID;
        }

        Cursor cursor = queryBuilder.query(sqlDB, projection, selection, selectionArgs, null,null, sortOrder);
        cursor.moveToFirst();
        cursor.setNotificationUri(getContext().getContentResolver(), uri);
        return cursor;
    }

    @Nullable
    @Override
    public String getType(Uri uri) {
        switch(urimatcher.match(uri)){
            case book:
                if (uri == BookContract.CONTENT_URI) {
                    return "vnd.android.cursor/vnd.edu.stevens.cs522.bookstore.books";
                } else
                    return "vnd.android.cursor/vnd.edu.stevens.cs522.bookstore.authors";

            case book_id:
                if (uri == BookContract.CONTENT_URI) {
                    return "vnd.android.cursor/vnd.edu.stevens.cs522.bookstore.books";
                } else
                    return "vnd.android.cursor/vnd.edu.stevens.cs522.bookstore.authors";

            default:
                throw new IllegalArgumentException("Unsupported URI "+ uri);

        }
    }

    @Nullable
    @Override
    public Uri insert(Uri uri, ContentValues values) {
        Log.i("Book Provider:","URI insert: URI="+uri.toString());
        Uri _uri = null;
        if (uri.equals( BookContract.CONTENT_URI)) {
            long rowID = sqlDB.insert(BookContract.BOOK_TABLE, null, values);
            if (rowID > 0){
                Log.i("Book Provider:","rowId > 0");
                _uri = ContentUris.withAppendedId(BookContract.CONTENT_URI,rowID);
                getContext().getContentResolver().notifyChange(_uri , null);
                return _uri;
            }
        }else if (uri.equals( AuthorContract.CONTENT_URI)) {
            long rowID = sqlDB.insert(AuthorContract.AUTHOR_TABLE, null, values);
            if (rowID > 0){
                Log.i("Book Provider:","rowId > 0");
                _uri = ContentUris.withAppendedId(AuthorContract.CONTENT_URI, rowID);
                getContext().getContentResolver().notifyChange(_uri , null);
                return _uri;
            }
        }else
            Toast.makeText(getContext(), "Row Insert Failed", Toast.LENGTH_LONG).show();
        return null;
    }

    @Override
    public int delete(Uri uri, String selection, String[] selectionArgs) {
        int rowsDeleted = 0;
        switch (urimatcher.match(uri)){
            case book:
                rowsDeleted = sqlDB.delete(BookContract.BOOK_TABLE, selection, selectionArgs);
                sqlDB.delete(AuthorContract.AUTHOR_TABLE, selection, selectionArgs);
                getContext().getContentResolver().notifyChange(uri,null);
                break;

            case book_id:
                String id = uri.getPathSegments().get(1);
                Log.i("Delete", "Delete id = "+id);
                rowsDeleted = sqlDB.delete(BookContract.BOOK_TABLE, BookContract.BOOK_TABLE+"."+BookContract.ID +" = "+Integer.parseInt(id)+(!TextUtils.isEmpty(selection) ? " AND (" + selection+ ')':""),selectionArgs);
                //rowsDeleted = sqlDB.delete(BookContract.BOOK_TABLE, BookContract.BOOK_TABLE+"."+BookContract.ID+" = "+id, selectionArgs);

                Log.i("Delete", "Rows Delete = " + rowsDeleted);
                sqlDB.delete(AuthorContract.AUTHOR_TABLE, AuthorContract.AUTHOR_TABLE + "." + AuthorContract.BOOK_FK + " = " + id + (!TextUtils.isEmpty(selection) ? " AND (" + selection + ')' : ""), selectionArgs);
                //sqlDB.delete(AuthorContract.AUTHOR_TABLE, AuthorContract.AUTHOR_TABLE + "." +AuthorContract.BOOK_FK+ " = "+ id, selectionArgs);

                getContext().getContentResolver().notifyChange(uri,null);
                break;

            default:
                throw new IllegalArgumentException("Unsupported URI" +uri);
        }


        return rowsDeleted;
    }

    @Override
    public int update(Uri uri, ContentValues values, String selection, String[] selectionArgs) {
        int rowsUpdated = 0;

        switch (urimatcher.match(uri)){
            case book:
                rowsUpdated = sqlDB.update(BookContract.BOOK_TABLE,values,selection,selectionArgs);
                break;

            case book_id:
                //rowsUpdated = sqlDB.update(BOOK_TABLE,values,selection,selectionArgs);

                rowsUpdated = sqlDB.update(BookContract.BOOK_TABLE, values,BookContract.ID + " = "+ uri.getPathSegments().get(1)+(!TextUtils.isEmpty
                        (selection)? " AND ("+ selection + ')' : ""), selectionArgs);
                break;

            default:
                throw new IllegalArgumentException("Unsupported URI" +uri);
        }

        getContext().getContentResolver().notifyChange(uri,null);

        return rowsUpdated;
    }

    private static class DatabaseHelper extends SQLiteOpenHelper {

        DatabaseHelper(Context context){
            super(context,DATABASE_NAME,null,DATABASE_VERSION);
        }

        @Override
        public void onCreate(SQLiteDatabase database) {
            database.execSQL(DATABASE_CREATE_BOOK_TABLE);
            database.execSQL(DATABASE_CREATE_AUTHOR_TABLE);
            database.execSQL(CREATE_INDEX);

        }

        @Override
        public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i2) {

            Log.w(DatabaseHelper.class.getName(),
                    "Upgrading database from version " + i + " to "
                            + i2 + ", which will destroy all old data");
            sqLiteDatabase.execSQL("DROP TABLE IF EXISTS "+BookContract.BOOK_TABLE);
            sqLiteDatabase.execSQL("DROP TABLE IF EXISTS "+AuthorContract.AUTHOR_TABLE);
            //  sqLiteDatabase.execSQL("DROP VIEW IF EXISTS "+VIEW_BOOK);
            onCreate(sqLiteDatabase);

        }
    }
}
