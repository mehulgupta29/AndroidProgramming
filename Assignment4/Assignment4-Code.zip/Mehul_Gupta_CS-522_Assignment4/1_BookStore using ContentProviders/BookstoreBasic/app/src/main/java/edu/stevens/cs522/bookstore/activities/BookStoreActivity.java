package edu.stevens.cs522.bookstore.activities;

import java.sql.SQLException;
import java.util.ArrayList;

import android.app.Activity;
import android.app.LoaderManager;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.content.CursorLoader;
import android.content.Intent;
import android.content.Loader;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.util.SparseBooleanArray;
import android.view.ActionMode;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.ResourceCursorAdapter;
import android.widget.TextView;
import android.widget.Toast;

import edu.stevens.cs522.bookstore.R;
import edu.stevens.cs522.bookstore.contracts.AuthorContract;
import edu.stevens.cs522.bookstore.contracts.BookContract;
import edu.stevens.cs522.bookstore.databases.CartDbAdapter;
import edu.stevens.cs522.bookstore.entities.Book;

public class BookStoreActivity extends Activity implements LoaderManager.LoaderCallbacks<Cursor> {
	
	// Use this when logging errors and warnings.
	@SuppressWarnings("unused")
	//private static final String TAG = BookStoreActivity.class.getCanonicalName();
	private static final String TAG = "BookStoreBasics_";
	
	// These are request codes for subactivity request calls
    static final private int SEARCH_REQUEST = 0;
    static final private int ADD_REQUEST = 1;
	
	@SuppressWarnings("unused")
	static final private int CHECKOUT_REQUEST = ADD_REQUEST + 1;

	// There is a reason this must be an ArrayList instead of a List.
	@SuppressWarnings("unused")
	private ArrayList<Book> shoppingCart = new ArrayList<Book>();	//data source
    private ListView bookStoreListView;	//ListView
    //private static final String BOOK_DETAILS = "Book_Details";
    private static final String SELECTED_BOOK = "SELECTED_BOOK";
    private static final int BOOKS_LOADER_ID = 1;

    //SimpleCursor Adapter
    //private CartDbAdapter cartDbAdapter;
    Cursor cursor;
    //private custCursorAdapter custAdapter;

    private BookAdapter bookAdapter;
    ContentResolver resolver;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

        // TODO check if there is saved UI state, and if so, restore it (i.e. the cart contents)
        resolver = getContentResolver();

        // TODO Set the layout (use cart.xml layout)
		setContentView(R.layout.cart);

        // TODO use an array adapter to display the cart contents.
        bookStoreListView = (ListView)findViewById(android.R.id.list);
        getData();
        registerForContextMenu(bookStoreListView);

        // For Contextual Action Menu
        bookStoreListView.setChoiceMode(ListView.CHOICE_MODE_MULTIPLE_MODAL);
        bookStoreListView.setMultiChoiceModeListener(new AbsListView.MultiChoiceModeListener() {
            @Override
            public void onItemCheckedStateChanged(ActionMode mode, int position, long id, boolean checked) {
                mode.setTitle(bookStoreListView.getCheckedItemCount() + " selected Items");
            }

            @Override
            public boolean onCreateActionMode(ActionMode mode, Menu menu) {
                Log.i(TAG, "creating action mode");
                mode.getMenuInflater().inflate(R.menu.context_action_bar_menu, menu);
                return true;
            }

            @Override
            public boolean onPrepareActionMode(ActionMode mode, Menu menu) {
                return false;
            }

            @Override
            public boolean onActionItemClicked(ActionMode mode, MenuItem item) {
                switch (item.getItemId()) {
                    case R.id.cab_menu_delete:
                        try {
                            Log.i(TAG, "action item delete clicked");
                            deleteSelectedBooks();

                            Toast.makeText(getBaseContext(), "Record deleted", Toast.LENGTH_SHORT).show();
                            mode.finish();
                            return true;

                        } catch (Exception sqlE) {
                            sqlE.printStackTrace();
                        } finally {
                            return false;
                        }
                    default:
                        return false;
                }
            }

            @Override
            public void onDestroyActionMode(ActionMode mode) {
                Log.i(TAG, "destroying action mode");
            }
        });

        bookStoreListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Cursor c = bookAdapter.getCursor();
                String _id = bookAdapter.getCursor().getString(c.getColumnIndex(BookContract.ID));
                Cursor cursor = getContentResolver().query(
                        BookContract.CONTENT_URI,
                        new String[]{BookContract.BOOK_TABLE + "." + BookContract.ID,
                                BookContract.TITLE, BookContract.ISBN,
                                BookContract.PRICE, "GROUP_CONCAT(" + AuthorContract.FIRST_NAME + "||' '||COALESCE(" + AuthorContract.MIDDLE_NAME + ",'-')||' '||" + AuthorContract.LAST_NAME + ",',') as " + BookContract.AUTHOR},
                        BookContract.BOOK_TABLE + "." + BookContract.ID + "=?",
                        new String[]{_id},
                        BookContract.BOOK_TABLE + "." + BookContract.ID);


                Book searchResult = null;
                if (cursor.moveToFirst()) {
                    Log.i(TAG, BookContract.getAuthors(cursor));
                    searchResult = new Book(cursor);
                }
                Intent intentData = new Intent(getApplicationContext(), DetailsActivity.class);
                Log.i(TAG, "setOnItemClickListener: BookDetails = " + searchResult.title + " ,"+ searchResult.isbn + " ," + searchResult.price);
                intentData.putExtra(constants.Detail, searchResult);
                startActivity(intentData);

            }
        });

        registerForContextMenu(bookStoreListView);
        bookStoreListView.setItemsCanFocus(true);
    }

    public void getData(){
        getLoaderManager().initLoader(BOOKS_LOADER_ID, null, this);
        bookAdapter = new BookAdapter(this,null);
        bookStoreListView.setAdapter(bookAdapter);
        TextView emptyText = (TextView)findViewById(android.R.id.empty);
        bookStoreListView.setEmptyView(emptyText);
    }

    private void deleteSelectedBooks() throws SQLException{
        Cursor cursor = null;
        SparseBooleanArray checked = bookStoreListView.getCheckedItemPositions();

        for(int i = 0; i < checked.size(); i++){
            if(checked.valueAt(i) == true){
                if(bookAdapter.getCursor().moveToPosition(i)) {
                    cursor = bookAdapter.getCursor();
                    String _id = bookAdapter.getCursor().getString(cursor.getColumnIndex(BookContract.ID));
                    Log.i(TAG, "Delete = "+_id);
                    Uri uri = Uri.parse(BookContract.CONTENT_URI + "/" + _id);
                    Log.i(TAG, "Delete = " + uri);
                    //getContentResolver().delete(uri, BookContract.BOOK_TABLE+"."+BookContract.ID + "=?", new String[] { _id });
                    getContentResolver().delete(uri, null, null);
                    bookAdapter.changeCursor(cursor);
                }
            }
        }
    }

    @Override
    public Loader<Cursor> onCreateLoader(int i, Bundle bundle) {
        CursorLoader cursorLoader;
        switch (i){
            case BOOKS_LOADER_ID:
                String[] projection = {BookContract.BOOK_TABLE+"."+BookContract.ID, BookContract.TITLE, BookContract.AUTHOR, BookContract.ISBN, BookContract.PRICE};
                cursorLoader = new CursorLoader(this, BookContract.CONTENT_URI, projection, null, null, null);
                break;
            default:
                cursorLoader = null;
                break;
        }

        return cursorLoader;
    }
    @Override
    public void onLoadFinished(Loader<Cursor> cursorLoader, Cursor cursor) {

        switch (cursorLoader.getId()) {
            case BOOKS_LOADER_ID:
                //bookAdapter.swapCursor(cursor);
                bookAdapter.changeCursor(cursor);
                break;
        }
    }
    @Override
    public void onLoaderReset(Loader<Cursor> cursorLoader) {
        //bookAdapter.swapCursor(cursor);
        bookAdapter.changeCursor(cursor);
    }

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		super.onCreateOptionsMenu(menu);
		// TODO provide ADD, DELETE and CHECKOUT options
        getMenuInflater().inflate(R.menu.bookstore_menu, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		super.onOptionsItemSelected(item);
		// TODO

        switch(item.getItemId()){
            case android.R.id.home:
                finish();
                break;

            case R.id.add:  // ADD provide the UI for adding a book
                Intent addIntent = new Intent(getApplicationContext(), AddBookActivity.class);
                startActivityForResult(addIntent, ADD_REQUEST);
                return true;

            case R.id.details:   // DELETE delete the currently selected book
                if(bookAdapter.getCursor() == null){
                    Toast.makeText(this, "Cart is Empty! Nothing to Display!", Toast.LENGTH_LONG).show();
                }else{
                    /*Intent detailsIntent = new Intent(getApplicationContext(), DetailsActivity.class);
                    cursor.moveToPosition(0);
                    Book displayBook = new Book(cursor);
                    detailsIntent.putExtra(constants.Detail, displayBook);
                    startActivity(detailsIntent);*/

                    Cursor c = bookAdapter.getCursor();
                    String _id = bookAdapter.getCursor().getString(c.getColumnIndex(BookContract.ID));
                    Cursor cursor = getContentResolver().query(
                            BookContract.CONTENT_URI,
                            new String[]{BookContract.BOOK_TABLE + "." + BookContract.ID,
                                    BookContract.TITLE, BookContract.ISBN,
                                    BookContract.PRICE, "GROUP_CONCAT(" + AuthorContract.FIRST_NAME + "||' '||COALESCE(" + AuthorContract.MIDDLE_NAME + ",'-')||' '||" + AuthorContract.LAST_NAME + ",',') as " + BookContract.AUTHOR},
                            BookContract.BOOK_TABLE + "." + BookContract.ID + "=?",
                            new String[]{_id},
                            BookContract.BOOK_TABLE + "." + BookContract.ID);


                    Book searchResult = null;
                    if (cursor.moveToFirst()) {
                        Log.i(TAG, BookContract.getAuthors(cursor));
                        searchResult = new Book(cursor);
                    }
                    Intent intentData = new Intent(getApplicationContext(), DetailsActivity.class);
                    Log.i(TAG, "setOnItemClickListener: BookDetails = " + searchResult.title + " ,"+ searchResult.isbn + " ," + searchResult.price);
                    intentData.putExtra(constants.Detail, searchResult);
                    startActivity(intentData);

                }
                return true;

            case R.id.checkout: // CHECKOUT provide the UI for checking out
                Intent checkOutIntent = new Intent(getApplicationContext(), CheckoutActivity.class);
                startActivityForResult(checkOutIntent, CHECKOUT_REQUEST);
                return true;
        }
	return false;
	}

    @Override
    protected void onActivityResult(int requestCode, int resultCode,
                                    Intent intent) {
        super.onActivityResult(requestCode, resultCode, intent);
        // TODO Handle results from the Search and Checkout activities.

        Book book;
        StringBuffer str = new StringBuffer();

        if(requestCode == ADD_REQUEST){
            if(resultCode == RESULT_OK){
                String actionBtn = (String)intent.getExtras().get(constants.button);
                if(actionBtn.equalsIgnoreCase("ADD")){  // ADD: add the book that is returned to the shopping cart.
                    try{
                        book = intent.getExtras().getParcelable(constants.book);
                        Log.i(TAG, "Book = " + book.id + " ," + book.title + " ,Author=" + book.authors[0].toString() + " ," + book.price);
                        ContentValues values = new ContentValues();
                        values.put(BookContract.TITLE, book.title);
                        values.put(BookContract.AUTHOR, book.authors[0].toString());
                        values.put(BookContract.ISBN, book.isbn);
                        values.put(BookContract.PRICE, book.price);
                        //book.writeToProvider(values);
                        ContentResolver contentResolver = this.getContentResolver();
                        Log.i(TAG, "Before contentResolver.insert(uri, values)");
                        Uri uri = contentResolver.insert(BookContract.CONTENT_URI, values);
                        Log.i(TAG, uri.getAuthority()+" ,"+uri.getPath());

                        ContentResolver contentResolver1 = this.getContentResolver();
                        for(int i=0;i<book.authors.length;i++)
                        {
                            ContentValues authorValues = new ContentValues();
                            authorValues.put(AuthorContract.FIRST_NAME,book.authors[i].firstName );
                            authorValues.put(AuthorContract.MIDDLE_NAME,book.authors[i].middleInitial );
                            authorValues.put(AuthorContract.LAST_NAME,book.authors[i].lastName );
                            authorValues.put(AuthorContract.BOOK_FK,uri.getLastPathSegment());

                            Uri uri1 = contentResolver1.insert(AuthorContract.CONTENT_URI, authorValues);
                            Log.i(TAG, uri1.getAuthority()+" ,"+uri1.getPath());
                        }

                        Toast.makeText(getApplicationContext(), "Book Added", Toast.LENGTH_SHORT).show();
                    }catch(Exception sqlE){
                        Toast.makeText(getApplicationContext(), "Book not added", Toast.LENGTH_SHORT).show();
                    }
                }else if(actionBtn.equalsIgnoreCase("SEARCH")){ // SEARCH: Search the book in the shopping cart database: if found then show the book details, else return back to Main activity
                    try{
                        Book searchBook = intent.getExtras().getParcelable(constants.Detail);
                        Book searchResult = null;
                        Cursor cursor = getContentResolver().query(
                                BookContract.CONTENT_URI,
                                new String[] { BookContract.BOOK_TABLE + "." + BookContract.ID,
                                        BookContract.TITLE, BookContract.ISBN,
                                        BookContract.PRICE, "GROUP_CONCAT("+AuthorContract.FIRST_NAME+"||' '||COALESCE("+AuthorContract.MIDDLE_NAME+",'-')||' '||"+AuthorContract.LAST_NAME+",'|') as "+BookContract.AUTHOR},
                                BookContract.BOOK_TABLE + "." + BookContract.ID + "=?",
                                new String[] { Integer.toString(searchBook.id) },
                                BookContract.BOOK_TABLE + "." + BookContract.ID);
                        if(cursor.moveToFirst()){
                            searchResult = new Book(cursor);
                        }
                        Intent intentData = new Intent(getApplicationContext(), DetailsActivity.class);
                        intentData.putExtra(constants.Detail, searchResult);
                        startActivity(intentData);

                    }catch(Exception sqlE){
                        Toast.makeText(getApplicationContext(), "Book not searched", Toast.LENGTH_SHORT).show();
                    }
                }
            }else if(resultCode == RESULT_CANCELED){
                Toast.makeText(this,"AddBook Cancelled",Toast.LENGTH_SHORT).show();
            }
        }else if(requestCode == CHECKOUT_REQUEST){  // CHECKOUT: empty the shopping cart.
            if(resultCode == RESULT_OK){
                int rowsDeleted = getContentResolver().delete(BookContract.CONTENT_URI, null, null);
                Toast.makeText(this, Integer.toString(rowsDeleted)+" Books Checked Out", Toast.LENGTH_SHORT).show();
            }else if(resultCode == RESULT_CANCELED){
                Toast.makeText(this,"Checkout Cancelled",Toast.LENGTH_SHORT).show();
            }
        }
    }

    @Override
	public void onSaveInstanceState(Bundle savedInstanceState) {
		// TODO save the shopping cart contents (which should be a list of parcelables).
		savedInstanceState.putParcelableArrayList(constants.list, shoppingCart);
        super.onSaveInstanceState(savedInstanceState);
	}

    public class BookAdapter extends ResourceCursorAdapter {
        protected final static int ROW_LAYOUT = R.layout.cart_row;

        public BookAdapter(Context context, Cursor cursor) {
            super(context, ROW_LAYOUT, cursor, 0);
        }

        @Override
        public View newView(Context context, Cursor cur, ViewGroup parent) {
            LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            return inflater.inflate(ROW_LAYOUT, parent, false);
        }

        @Override
        public void bindView(View view, Context context, Cursor cursor) {
            TextView txtTitle = (TextView) view.findViewById(R.id.cart_row_title);
            txtTitle.setText(BookContract.getTitle(cursor));

            TextView txtAuthors = (TextView) view.findViewById(R.id.cart_row_author);
            txtAuthors.setText(BookContract.getAuthors(cursor));

            TextView txtIsbn = (TextView) view.findViewById(R.id.cart_row_isbn);
            txtIsbn.setText(BookContract.getIsbn(cursor));

            TextView txtPrice = (TextView) view.findViewById(R.id.cart_row_price);
            txtPrice.setText(BookContract.getPrice(cursor));
        }
    }
}