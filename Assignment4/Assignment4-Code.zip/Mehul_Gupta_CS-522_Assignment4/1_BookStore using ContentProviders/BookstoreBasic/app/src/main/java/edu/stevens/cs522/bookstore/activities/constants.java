package edu.stevens.cs522.bookstore.activities;

/**
 * Created by DV6 on 2/9/2016.
 */
public class constants {
    public static String book = "Book";
    public static String list = "list";
    public static String button = "Button";
    public static String Detail = "Details";
}
