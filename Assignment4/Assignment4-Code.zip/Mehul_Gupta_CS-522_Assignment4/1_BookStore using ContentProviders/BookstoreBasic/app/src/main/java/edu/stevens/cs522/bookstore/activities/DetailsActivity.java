package edu.stevens.cs522.bookstore.activities;


import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;

import java.util.regex.Pattern;

import edu.stevens.cs522.bookstore.R;
import edu.stevens.cs522.bookstore.entities.Author;
import edu.stevens.cs522.bookstore.entities.Book;


public class DetailsActivity extends Activity {

    private static final String BOOK_DETAILS = "Book_Details";
    private TextView titleTV, authorsTV, priceTV, isbnTV;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_details);

        titleTV = (TextView)findViewById(R.id.detailsTitleValueTextView);
        authorsTV = (TextView)findViewById(R.id.detailsAuthorsValuesTextView);
        isbnTV = (TextView)findViewById(R.id.detailsISBNValuesTextView);
        priceTV = (TextView)findViewById(R.id.detailsPriceValueTextView);


        Book book = getIntent().getExtras().getParcelable(constants.Detail);
        titleTV.setText(book.getTitle());
        //Log.i(constants.Detail, "AuthorList from BookStore= " + book.authors[0].toString());
        //DIsplay Authours
        Author[] authors = book.authors;
        String authorStr = "";
        for(Author a : authors){
            if(a.middleInitial != null){
                authorStr += a.firstName+" "+a.middleInitial+" "+a.lastName;
            }else{
                authorStr += a.firstName+" "+a.lastName;
            }
            authorStr += "\n";
        }
        authorsTV.setText(authorStr);
        isbnTV.setText(book.getIsbn());
        priceTV.setText(book.getPrice());

        Log.i("DetailsActivity:  ", new Integer(book.id).toString() );
    }


    public static final char SEPARATOR_CHAR = '|';
    private static final Pattern SEPARATOR =   Pattern.compile(Character.toString(SEPARATOR_CHAR), Pattern.LITERAL);
    public static String[] readStringArray(String in) {   return SEPARATOR.split(in);}

    public Author[] generateAuthors(String authorEV){
        String [] authorArray = readStringArray(authorEV); //authorEV.split(",");
        Author[] authors = Author.CREATOR.newArray(authorArray.length);
        int index = 0;
        for(String author : authorArray){
            Author a = null;
            String [] authorFullName = author.split("\\s+");
            if(authorFullName.length == 1){
                a = new Author(authorFullName[0]);
            }else if(authorFullName.length == 2){
                a = new Author(authorFullName[0], authorFullName[1]);
            }else if(authorFullName.length == 3){
                a = new Author(authorFullName[0], authorFullName[1], authorFullName[2]);
            }else{
                Log.i("Array_DetailsActivity", "Error in authors");
            }
            authors[index] = a;
            Log.i(constants.Detail, "DetailsActivity: Author List="+authors[index].firstName+" "+authors[index].lastName);
            index++;
        }

        return authors;
    }
}
