package edu.stevens.cs522.bookstore.databases;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import java.sql.SQLException;

import edu.stevens.cs522.bookstore.contracts.BookContract;
import edu.stevens.cs522.bookstore.entities.Author;
import edu.stevens.cs522.bookstore.entities.Book;

/**
 * Created by DV6 on 2/9/2016.
 */
public class CartDbAdapter {

    private static final String DATABASE_NAME = "book.db";
    private static final String BOOK_TABLE = "book";
    private static final String AUTHOR_TABLE = "author";
    private static final int DATABASE_VERSION = 1;
    private static final String ID = "_id";
    private static final String TITLE = "title";
    private static final String AUTHOR = "authors";
    private static final String ISBN = "isbn";
    private static final String PRICE = "price";
    private static final String FIRST_NAME = "first_name";
    private static final String MIDDLE_NAME = "middle_name";
    private static final String LAST_NAME = "last_name";
    private static final String BOOK_FK = "foreign_key";
    private static final String VIEW_BOOK = "book_author_view";
    private static final String DATABASE_CREATE_BOOK_TABLE = "create table " + BOOK_TABLE + " (" + ID + " integer primary key autoincrement," +
            TITLE + " text," + ISBN + " text," + PRICE + " text);";
    private static final String DATABASE_CREATE_AUTHOR_TABLE = "create table " + AUTHOR_TABLE + " (" + ID + " integer primary key autoincrement," +
            FIRST_NAME + " text," + MIDDLE_NAME + " text," + LAST_NAME + " text," + BOOK_FK + " integer not null,foreign key (" + BOOK_FK + ") references " +
            BOOK_TABLE + "(" + ID + ")on delete cascade );";

    public static String CREATE_INDEX = "Create index AuthorsBookIndex on" + AUTHOR_TABLE + "(" + BOOK_FK + ");";
    public static final String BOOK_LEFT_JOIN_AUTHOR = "SELECT "+BOOK_TABLE+"."+ID+", "+TITLE+", GROUP_CONCAT("+FIRST_NAME+"||' '||COALESCE("+MIDDLE_NAME+",'-')||' '||"+LAST_NAME+" , '|') as "+AUTHOR+", "+ISBN+", "+PRICE+" FROM "+BOOK_TABLE+" LEFT OUTER JOIN "+AUTHOR_TABLE+" ON "+BOOK_TABLE+"."+ID+" = "+AUTHOR_TABLE+"."+BOOK_FK+" GROUP BY "+BOOK_TABLE+"."+ID+" ,"+TITLE+" ,"+ISBN+" ,"+PRICE;
    public static String CREATE_VIEW = "create view " + VIEW_BOOK + " as "+BOOK_LEFT_JOIN_AUTHOR;

    public static String row_id = "select last_insert_rowid() from "+BOOK_TABLE;

    private SQLiteDatabase db;
    private Context context;
    DatabaseHelper dbHelper;


    public CartDbAdapter(Context context) {
        this.context = context;
        dbHelper = new DatabaseHelper(context);
    }

    private static class DatabaseHelper extends SQLiteOpenHelper{
        public DatabaseHelper(Context context) {
            super(context, DATABASE_NAME, null, DATABASE_VERSION);
        }

        @Override
        public void onCreate(SQLiteDatabase db) {
            db.execSQL(DATABASE_CREATE_BOOK_TABLE);
            db.execSQL(DATABASE_CREATE_AUTHOR_TABLE);
            db.execSQL(CREATE_VIEW);
            //db.execSQL(CREATE_INDEX);
        }

        @Override
        public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

            Log.w(DatabaseHelper.class.getName(), "Upgrading " + DATABASE_NAME + " version: old Version = " + oldVersion + " , new Version = " + newVersion + " : All old data will be lost");
            db.execSQL("DROP TABLE IF EXISTS " + BOOK_TABLE);
            db.execSQL("DROP TABLE IF EXISTS " + AUTHOR_TABLE);
            db.execSQL("DROP VIEW IF EXISTS "+ VIEW_BOOK);
            //db.execSQL("DROP INDEX IF EXISTS "+ CREATE_INDEX);
            onCreate(db);
        }
    }

    public CartDbAdapter open() throws SQLException{
        db = dbHelper.getWritableDatabase();
        db.execSQL("PRAGMA foreign_keys = ON;");
        return this;
    }

    public Cursor fetchAllBooks(){
         return db.query(VIEW_BOOK, new String[]{ID,TITLE, AUTHOR, ISBN, PRICE}, null, null, null, null, null);
    }

    public int searchBookByBookTitle(Book book){
        String query = "SELECT "+BOOK_TABLE+"."+ID+", "+TITLE+", GROUP_CONCAT("+FIRST_NAME+"||' '||COALESCE("+MIDDLE_NAME+",'-')||' '||"+LAST_NAME+" , '|') as "+AUTHOR+", "+ISBN+", "+PRICE+" FROM "+BOOK_TABLE+" LEFT OUTER JOIN "+AUTHOR_TABLE+" ON "+BOOK_TABLE+"."+TITLE+" = '"+book.title+"' GROUP BY "+BOOK_TABLE+"."+ID+" ,"+TITLE+" ,"+ISBN+" ,"+PRICE;
        String [] selectionArgs = null;
        Cursor cursor = db.rawQuery(query, selectionArgs);
        if(cursor.moveToFirst()){
            Book b = new Book(cursor);
            return b.id;
        }
        cursor.close();
        return 0;
    }

    public Book fetchBook(int id){

        String [] selectionArgs = null;
        Cursor cursor = db.rawQuery(BOOK_LEFT_JOIN_AUTHOR, selectionArgs);
        if(cursor.moveToFirst()){
            Book book = new Book(cursor);
            return book;
        }
        cursor.close();
        return null;
    }

    public void persist(Book book) throws SQLException{
        ContentValues contentValues = new ContentValues();

        //Insert into BOOK Table
        contentValues.put(TITLE, book.title);
        //contentValues.put(AUTHOR, book.authors[0].toString());
        contentValues.put(ISBN, book.isbn);
        contentValues.put(PRICE, book.price);

        db.insert(BOOK_TABLE, null, contentValues);
        contentValues.clear();

        //Insert into AUTHOR Table
        Cursor cursor = db.rawQuery(row_id, null);
        cursor.moveToFirst();

        for(Author a : book.authors){
            contentValues.put(FIRST_NAME, a.firstName);
            contentValues.put(MIDDLE_NAME, a.middleInitial);
            contentValues.put(LAST_NAME, a.lastName);

            if(cursor != null)
                contentValues.put(BOOK_FK, cursor.getInt(0));
            db.insert(AUTHOR_TABLE, null, contentValues);
            contentValues.clear();
        }

        //Close Cursor connection
        cursor.close();
    }


    public boolean delete(Book book){
        return db.delete(BOOK_TABLE, BookContract.BOOK_TABLE+"."+ID+" = "+book.id, null) > 0;
    }

    public boolean deleteAll(){
        return db.delete(BOOK_TABLE, null, null) > 0;
    }

    public void close(){
        db.close();
    }
}
