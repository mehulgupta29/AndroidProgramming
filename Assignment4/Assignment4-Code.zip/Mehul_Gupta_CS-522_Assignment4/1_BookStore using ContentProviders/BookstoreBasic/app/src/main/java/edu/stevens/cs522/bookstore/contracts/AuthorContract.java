package edu.stevens.cs522.bookstore.contracts;

import android.content.ContentValues;
import android.database.Cursor;
import android.net.Uri;

/**
 * Created by DV6 on 2/7/2016.
 */
public class AuthorContract {

    public static final String ID = "_id";
    public static final int ID_KEY = 0;
    public static final String FIRST_NAME = "first_name";
    public static final int FIRST_NAME_KEY = 1;
    public static final String MIDDLE_NAME = "middle_name";
    public static final int MIDDLE_NAME_KEY = 2;
    public static final String LAST_NAME = "last_name";
    public static final int LAST_NAME_KEY = 3;
    public static final String BOOK_FK = "foreign_key";
    public static final int BOOK_FK_KEY = 4;

    public static final String AUTHORITY = "edu.stevens.cs522.bookstore";
    public static final String AUTHOR_TABLE = "author";
    public static final String CONTENT_PATH = "/"+AUTHOR_TABLE;
    public static final String URL = "content://"+AUTHORITY+CONTENT_PATH;
    public static Uri CONTENT_URI = Uri.parse(URL);




    public static String getAuthorId(Cursor cursor){
        return cursor.getString(cursor.getColumnIndexOrThrow(ID));
    }
    public static void putAuthorId(ContentValues contentValues, String author_id){
        contentValues.put(ID, author_id);
    }
    public static String getFirstName(Cursor cursor){
        return cursor.getString(cursor.getColumnIndexOrThrow(FIRST_NAME));
    }
    public static void putFirstName(ContentValues contentValues, String first_name){
        contentValues.put(FIRST_NAME, first_name);
    }
    public static String getMiddleInitial(Cursor cursor){
        return cursor.getString(cursor.getColumnIndexOrThrow(MIDDLE_NAME));
    }
    public static void putMiddleInitial(ContentValues contentValues, String middle_initial){
        contentValues.put(MIDDLE_NAME, middle_initial);
    }
    public static String getLastName(Cursor cursor){
        return cursor.getString(cursor.getColumnIndexOrThrow(LAST_NAME));
    }
    public static void putLastName(ContentValues contentValues, String last_name){
        contentValues.put(LAST_NAME, last_name);
    }

}
