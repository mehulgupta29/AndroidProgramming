package edu.stevens.cs522.capture.util;

public interface IContinue<T> {
	
	public void kontinue(T value);

}
