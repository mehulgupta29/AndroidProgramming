package edu.stevens.cs522.requests;

import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URI;
import java.net.URL;
import java.net.URLConnection;

import android.util.JsonReader;
import android.util.Log;

public class RestMethod {

    public static final String TAG = RestMethod.class.getCanonicalName();

    public Response perform(Register request) {
        Log.d(TAG, "Response perform(Register)");
        long clientId;
        Response response = new Response();

        // Send data
        try {
            // Defined URL where to send data
            URL url = new URL(request.getRequestUri().toString());

            // Send POST data request
            Log.d(TAG, "RestMethod: " + url.toString());
            URLConnection connection = url.openConnection();
            HttpURLConnection conn = (HttpURLConnection) connection;
            conn.setReadTimeout(10);//10000
            conn.setConnectTimeout(15);//15000
            conn.setRequestProperty("Content-Type", "application/json");
            conn.setRequestProperty("Accept", "application/json");
            conn.setRequestProperty("X-latitude", "78.7639505");
            conn.setRequestProperty("X-longitude", "-54.023937");
            conn.setRequestMethod("POST");

            response.status = conn.getResponseCode();
            Log.d(TAG, "Response Code: " + String.valueOf(response.status));
            if (response.status == 201) {
                response.headers = conn.getHeaderFields();
                InputStream in = conn.getInputStream();
                JsonReader jr = new JsonReader(new InputStreamReader(in, "UTF-8"));
                jr.beginObject();
                if (jr != null) {
                    jr.nextName();
                    clientId = jr.nextLong();
                    response.body = String.valueOf((clientId));
                    Log.d(TAG, "clientIdResponse: " + String.valueOf(response.body));
                }
                jr.close();
            }
        } catch (Exception ex) {
            Log.e(TAG, "RestMethod: " + ex.getMessage());
        }
        finally {
            if(conn != null)
                conn.disconnect();
        }
        return response;
    }

    public StreamingResponse perform(Synchronize request) {
        Log.d(TAG, "StreamingResponse perform(Sync)");
        HttpURLConnection conn = null;
        StreamingResponse response = null;
        JsonReader rd = null;
        try {
            conn = (HttpURLConnection) new URI(request.getRequestUri().toString()).toURL().openConnection();
            response = request.getResponse(conn, rd);
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }finally {
            if(conn!=null)
                conn.disconnect();
        }
        Log.d(TAG, "StreamingResponse perform(Sync) end");
        return response;
    }

    HttpURLConnection conn = null;

    public Response perform(Unregister request) {
        Log.d(TAG, "Response perform(Unregister");

        long clientId;
        Response response = new Response();
        try {
            // Defined URL where to send data
            URL url = new URL(request.getRequestUri().toString());
            // Send POST data request
            Log.d(TAG, "Perform(Unregister): " + url.toString());
            URLConnection connection = url.openConnection();
            conn = (HttpURLConnection) connection;
            conn.setReadTimeout(1000);//10000
            conn.setConnectTimeout(1500);//15000
            conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
            conn.setRequestMethod("DELETE");
            response.status = conn.getResponseCode();
            Log.d(TAG, "Response Code: " + String.valueOf(response.status));

        } catch (Exception ex) {
            Log.e(TAG, "RestMethod: " + ex.getMessage());
        } finally {
            if (conn != null) {
                conn.disconnect();
            }
        }
        return null;

    }
}
