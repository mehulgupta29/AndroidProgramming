package edu.stevens.cs522.activities;

import java.util.Date;
import java.util.regex.Pattern;

import android.app.Activity;
import android.app.AlarmManager;
import android.app.LoaderManager;
import android.app.PendingIntent;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.content.CursorLoader;
import android.content.Intent;
import android.content.Loader;
import android.content.SharedPreferences;
import android.content.res.Resources;
import android.database.Cursor;
import android.os.Bundle;
import android.os.SystemClock;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.SimpleCursorAdapter;

import edu.stevens.cs522.constants.constant;
import edu.stevens.cs522.entities.ChatMessage;
import edu.stevens.cs522.providers.CloudProvider;
import edu.stevens.cs522.services.AlarmReceiver;

public class ChatApp extends Activity implements
		LoaderManager.LoaderCallbacks<Cursor> {
	final static public String TAG = ChatApp.class.getCanonicalName();

	public static final char SEPARATOR_CHAR = '|';
	private static final Pattern SEPARATOR = Pattern.compile(Character.toString(SEPARATOR_CHAR), Pattern.LITERAL);
	public static String[] readStringArray(String in) {
		return SEPARATOR.split(in);
	}

	EditText msgTxt;
	Button send;

	private String clientName;
	private String portNo;
	private String hostStr;
	private String uuidStr;
    private Date date;

	AlarmManager alarmManager;
	ListView msgList;
	ContentResolver cr;
	SimpleCursorAdapter msgAdapter;
    String clientId;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);

		Intent myIntent = getIntent();
		clientId = myIntent.getStringExtra(constant.CLIENT_ID);
		msgList = (ListView) findViewById(R.id.msgList);
		msgTxt = (EditText) findViewById(R.id.message_text);
        date = new Date();

		//Display List view
		cr = getContentResolver();
		Cursor cursor = cr.query(CloudProvider.CONTENT_URI, null, null, null, null);
		msgAdapter = new SimpleCursorAdapter(this, android.R.layout.simple_list_item_2, null, new String[] {"sender", "text" },
				new int[] { android.R.id.text1,android.R.id.text2 });
		msgList.setAdapter(msgAdapter);
		msgAdapter.changeCursor(cursor);
		cursor.close();

		//Get values from SharedPreferences
		SharedPreferences prefs = this.getSharedPreferences(constant.SHARED_PREF, Context.MODE_PRIVATE);
		uuidStr = prefs.getString(constant.CLIENT_UUID,"00000000-a3e8-11e3-a5e2-0800201c9a66");
		clientName = prefs.getString(constant.CLIENT_NAME, "MEHUL");
		portNo = prefs.getString(constant.PORT, "8080");
		hostStr = prefs.getString(constant.HOST, "localhost");

		//Send Button
		Resources res = getResources();
		send = (Button) findViewById(R.id.send_button);
		send.setOnClickListener(sendListener);

		Long time = (long) (1);
		Intent intentAlarm = new Intent(this, AlarmReceiver.class);
		PendingIntent sender = 	PendingIntent.getBroadcast(this, 12, intentAlarm,0);
		intentAlarm.putExtra(constant.CLIENT_ID, clientId);
		alarmManager = (AlarmManager) getSystemService(Context.ALARM_SERVICE);

		// set the alarm for particular time
		alarmManager.setRepeating(AlarmManager.ELAPSED_REALTIME_WAKEUP,
				SystemClock.elapsedRealtime(), time, 
				sender);
		//Toast.makeText(this, "Sync server within 5s", Toast.LENGTH_SHORT).show();
	}
	private OnClickListener sendListener = new OnClickListener() {
		public void onClick(View v) {
			ContentValues cv = new ContentValues();
			ChatMessage cm = new ChatMessage(0, msgTxt.getText().toString(),
					clientName, 0, new Date().getTime());

            cm.writeToProvider(cv);
			try {
				getContentResolver().insert(CloudProvider.CONTENT_URI,cv);

			} catch (Exception e) {
				e.printStackTrace();
			}
			Cursor cursor = cr.query(CloudProvider.CONTENT_URI, null, null, null, null);
			msgAdapter.changeCursor(cursor);
		};
	};

	@Override
	public void onStop(){
		super.onStop();
		Intent intentAlarm = new Intent(this, AlarmReceiver.class);
		alarmManager = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
		PendingIntent sender = 	PendingIntent.getBroadcast(this, 12, intentAlarm,0);
		try {
			 alarmManager.cancel(sender);
			 Log.i(TAG,"onStop: before unregister");
			 //ServiceHelper.getInstance(this).unregister()
		} catch (Exception e) {
			Log.e(TAG, "AlarmManager update was not canceled. " + e.toString());
		}
	}

	@Override
	public void onDestroy(){
		super.onDestroy();
		Intent intentAlarm = new Intent(this, AlarmReceiver.class);
		alarmManager = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
		PendingIntent sender = 	PendingIntent.getBroadcast(this, 12, intentAlarm,0);
		 try {
			 alarmManager.cancel(sender);
		 } catch (Exception e) {
			 Log.e(TAG, "AlarmManager update was not canceled. " + e.toString());
		 }
		 cr.delete(CloudProvider.CONTENT_URI, null, null);
		 cr.delete(CloudProvider.CONTENT_URI_PEER, null, null);

	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		super.onCreateOptionsMenu(menu);

		this.getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		super.onOptionsItemSelected(item);
		switch (item.getItemId()) {
		case (R.id.show_peers):
			Intent intentPeers = new Intent(this, PeersActivity.class);
			startActivityForResult(intentPeers, 2);
			return true;
        case (R.id.show_settings):
            Intent intentSettings = new Intent(this, EntryActivity.class);
			startActivityForResult(intentSettings, 2);
            return true;
		}
		return false;
	}
	public Loader<Cursor> onCreateLoader(int arg0, Bundle arg1) {

		return new CursorLoader(this, CloudProvider.CONTENT_URI,
				CloudProvider.MessageProjection, null, null, null);
	}

	public void onLoadFinished(Loader<Cursor> loader, Cursor cursor) {
		this.msgAdapter.swapCursor(cursor);
	}

	public void onLoaderReset(Loader<Cursor> loader) {
		this.msgAdapter.swapCursor(null);
	}

}
