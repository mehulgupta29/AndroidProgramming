package edu.stevens.cs522.helpers;

import edu.stevens.cs522.constants.constant;
import edu.stevens.cs522.requests.Register;
import edu.stevens.cs522.requests.Unregister;
import edu.stevens.cs522.services.RequestService;

import android.content.Context;
import android.content.Intent;
import android.os.ResultReceiver;
import android.util.Log;

public class ServiceHelper {

    public static final String TAG = ServiceHelper.class.getCanonicalName();

    public Context ctx;
    private static Object lock = new Object();
    private static ServiceHelper instance;

    private ServiceHelper(Context ctx) {
        this.ctx = ctx.getApplicationContext();
    }

    public static ServiceHelper getInstance(Context ctx) {
        synchronized (lock) {
            if (instance == null) {
                instance = new ServiceHelper(ctx);
            } else {
                instance.ctx = ctx.getApplicationContext();
            }
        }
        return instance;
    }

    public void register(Register register, ResultReceiver receiver) {
        Intent intent = new Intent(constant.REGISTER_ACTION);
        Log.d(TAG, "register()" + this.ctx.getClass().toString());
        intent.putExtra(constant.REGISTER, register);
        intent.putExtra(constant.RECEIVER, receiver);
        this.ctx.startService(intent);
        // TODO Auto-generated method stub

    }

    public void sync() {
        Intent intent = new Intent(ctx, RequestService.class);
        Log.d(TAG, "Sync()" + this.ctx.getClass().toString());
        intent.putExtra(constant.TYPE_FLAG, 1);
        this.ctx.startService(intent);

    }


    public void unregister(Unregister unregister) {
        // TODO Auto-generated method stub
        Intent intent = new Intent(constant.UNREGISTER_ACTION);
        Log.d(TAG, "unRegister()" + this.ctx.getClass().toString());
        intent.putExtra(constant.UNREGISTER, unregister);
        this.ctx.startService(intent);
    }

}
