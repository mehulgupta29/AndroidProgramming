package edu.stevens.cs522.constants;

/**
 * Created by DV6 on 3/10/2016.
 */
public class constant {
    public static final String NAME = "name";
    public static final String PORT = "port";
    public static final String HOST = "host";
    public static final String SHARED_PREF = "chatappcloud";
    public static final String latitude = "40.7439905";
    public static final String longitude = "-74.0323626";


    public static final String CLIENT_ID = "clientID";
    public static final String CLIENT_NAME = "clientName";
    public static final String CLIENT_UUID = "clientUUID";
    public static final String X_LATITUDE = "X-latitude";
    public static final String X_LONGITUDE = "X-longitude";
    public static final int DEFAULT_CLIENT_PORT = 8080;
    public static final String CLIENT_PORT_KEY = "client_port";

    public static final String REGISTER_ACTION = "edu.stevens.cs522.chatappcloud.register";
    public static final String SYNCHRONIZE_ACTION = "edu.stevens.cs522.chatappcloud.synchronize";
    public static final String UNREGISTER_ACTION = "edu.stevens.cs522.chatappcloud.unregister";

    public static final String REGISTER = "register";
    public static final String UNREGISTER = "unregister";
    public static final String RECEIVER = "receiver";
    public static final String TYPE_FLAG = "type";


}
