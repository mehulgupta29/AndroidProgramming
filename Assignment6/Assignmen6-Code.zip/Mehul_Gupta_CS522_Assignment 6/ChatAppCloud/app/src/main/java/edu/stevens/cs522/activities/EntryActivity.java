package edu.stevens.cs522.activities;

import java.util.UUID;

import edu.stevens.cs522.constants.constant;
import edu.stevens.cs522.requests.Unregister;
import edu.stevens.cs522.helpers.ServiceHelper;
//import edu.stevens.cs522.helper.ServiceHelper;
import edu.stevens.cs522.requests.Register;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.ResultReceiver;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

@SuppressLint("NewApi")
public class EntryActivity extends Activity {

    public static final String TAG = EntryActivity.class.getCanonicalName();
    AckReceiver receiver;
    String clientName, portNo, hostStr, uuid, client;
    Context mContext;
    boolean flag = false;
    UUID u = null;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_set_head);
        receiver = new AckReceiver(new Handler());
        mContext = this.getApplicationContext();
        u = UUID.randomUUID();
        uuid = u.toString();
        Log.i(TAG, "onCreate: after setting sharedPreferences: uuid=" + uuid);
    }


    @Override
    protected void onStart() {
        super.onStart();
        if (flag) {
            Log.i(TAG, "unregister() start");
            // http://10.0.2.2:8080/chat?username=me20&regid=6213074c-0ad2-458c-88b8-1a01c15a144c
            Unregister unregister = new Unregister(Long.parseLong(client), u, Uri.parse("http://" + hostStr + ":" + portNo));
            ServiceHelper.getInstance(this).unregister(unregister);
            Log.i(TAG, "unregister() end");
        }
    }

    public class AckReceiver extends ResultReceiver {
        public AckReceiver(Handler handler) {
            super(handler);
            // TODO Auto-generated constructor stub
        }

        protected void onReceiveResult(int resultCode, Bundle result) {
            switch (resultCode) {
                case 1:
                    client = result.getString("clientId");
                    if (client != null) {
                        Log.d(TAG, "OnReceiveResult id:" + client);
                    }
                    Intent i = new Intent(mContext, ChatApp.class);
                    i.putExtra(constant.NAME, clientName);
                    i.putExtra(constant.PORT, portNo);
                    i.putExtra(constant.HOST, hostStr);
                    i.putExtra(constant.CLIENT_ID, client);
                    startActivity(i);
                    break;
                case 0:
                    Toast.makeText(mContext, "Login Fail, Can't find server.", Toast.LENGTH_SHORT).show();
                    break;
                default:
                    break;
            }
        }
    };

    // the function will be called when the start chat button is clicked
    public void login(View view) {
        Log.i(TAG, "login()");
        EditText username = (EditText) findViewById(R.id.name_field);
        EditText port = (EditText) findViewById(R.id.port_text);
        EditText host = (EditText) findViewById(R.id.dest_text);
        clientName = username.getText().toString();
        portNo = port.getText().toString();
        hostStr = host.getText().toString();

        if (username.getText().toString().matches("") || port.getText().toString().matches("") || host.getText().toString().matches("")) {
            Toast.makeText(this, "Missing Input", Toast.LENGTH_SHORT).show();
        } else {

            Register register = new Register(0, UUID.fromString(uuid), clientName, "http://" + hostStr + ":" + portNo);
            SharedPreferences prefs = this.getSharedPreferences(constant.SHARED_PREF, Context.MODE_PRIVATE);
            SharedPreferences.Editor editor = prefs.edit();
            editor.putString(constant.CLIENT_NAME, register.username);
            editor.putString(constant.PORT, portNo);
            editor.putString(constant.HOST, hostStr);
            editor.putString(constant.CLIENT_UUID, uuid);
            editor.putString(constant.X_LATITUDE, constant.latitude);
            editor.putString(constant.X_LONGITUDE, constant.longitude);
            editor.commit();

            Log.i(TAG, "login(): after sharedPreferences");
            ServiceHelper.getInstance(this).register(register, receiver);
            flag = true;
            Log.i(TAG, "login(): after ServiceHelper.getInstance.register");
        }

    }
}
