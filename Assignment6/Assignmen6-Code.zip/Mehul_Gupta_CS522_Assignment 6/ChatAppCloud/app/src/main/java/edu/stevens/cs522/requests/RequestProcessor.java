package edu.stevens.cs522.requests;

import edu.stevens.cs522.constants.constant;
import edu.stevens.cs522.entities.Peer;
import edu.stevens.cs522.entities.ChatMessage;
import edu.stevens.cs522.providers.CloudProvider;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.os.ResultReceiver;
import android.util.Log;

public class RequestProcessor {

    public static final String TAG = RequestProcessor.class.getCanonicalName();

    RestMethod restMethod = new RestMethod();
    ContentResolver cr;

    public RequestProcessor(ContentResolver cr) {
        super();
        this.cr = cr;
    }

    public void perform(Register request, ResultReceiver resultReceiver) {
        Log.i(TAG, "perform(Register, ResultReceiver) start");

        Response response = restMethod.perform(request);
        Bundle bundle = new Bundle();
        ContentValues newValues = new ContentValues();
        newValues.put("name", request.username);
        newValues.put("_id", response.body);
        Uri uri = cr.insert(CloudProvider.CONTENT_URI_PEER, newValues);
        if (uri != null) {
            Log.i(TAG, "insert succes: " + uri.toString());
        }

        bundle.putString(constant.CLIENT_ID, response.body);
        Log.i(TAG, "perform(r,rr): before rr.send(): username=" + request.username + " ,body=" + response.body);
        resultReceiver.send(1, bundle);
    };

    public void perform(Synchronize request) {
        Log.i(TAG, "perform(Sync(request))");
        Cursor cursor = cr.query(CloudProvider.CONTENT_URI, null, "messageid=?", new String[]{"0"}, null);
        String t = "";
        ChatMessage cm1;
        if (cursor.moveToFirst()) {
            do {
                cm1 = new ChatMessage(cursor);
                Log.d(TAG, "message to upload " + cm1.messageText);
                t = cm1.messageText;
            } while (cursor.moveToNext());
        }
        request.message = t;
        StreamingResponse response = restMethod.perform(request);

        //update list of peers
        cr.delete(CloudProvider.CONTENT_URI_PEER, null, null);
        if (response.usersList != null) {
            Log.i(TAG, "response.usersList is NOT null");
            for (String name : response.usersList) {
                ContentValues values = new ContentValues();
                new Peer(name, 1).writeToProvider(values);
                Log.d(TAG, "inserted peer: " + cr.insert(CloudProvider.CONTENT_URI_PEER, values).toString());
            }

            Log.i(TAG, "after for loop");
            //add new message to database
            //delete all messageid =0 message
            int i = cr.delete(CloudProvider.CONTENT_URI, "messageid=?", new String[]{"0"});
            Log.d(TAG, "Temp Msg been delete: " + String.valueOf(i));
            for (String[] msg : response.msgList) {
                ChatMessage cm;
                cm = new ChatMessage(0, msg[4], msg[3], Long.parseLong(msg[2]), Long.parseLong(msg[1]));

                ContentValues values = new ContentValues();
                cm.writeToProvider(values);
                cr.insert(CloudProvider.CONTENT_URI, values);
            }
        }
        Log.i(TAG, "response.usersList is null");
    };

    public void perform(Unregister request) {
        Log.i(TAG, "perform(Unregister");
        restMethod.perform(request);
    };
}
