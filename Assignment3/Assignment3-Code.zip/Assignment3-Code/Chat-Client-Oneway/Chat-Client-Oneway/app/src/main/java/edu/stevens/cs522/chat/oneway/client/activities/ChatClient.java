package edu.stevens.cs522.chat.oneway.client.activities;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.sql.SQLException;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.StrictMode;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import edu.stevens.cs522.chat.oneway.client.R;

public class ChatClient extends Activity implements OnClickListener {

    final static private String TAG = ChatClient.class.getSimpleName();
    final static private int PREFERENCES = 1;

    /*
     * Client name (should be entered in a parent activity, provided as an extra in the intent).
     */
    public static final String CLIENT_NAME_KEY = "client_name";
    public static final String DEFAULT_CLIENT_NAME = "client";

    private String CLIENT_NAME;

    /*
     * Client UDP port (should be entered in a parent activity, provided as an extra in the intent).
     */
    public static final String CLIENT_PORT_KEY = "client_port";
    public static final int DEFAULT_CLIENT_PORT = 6666;

    /*
     * Socket used for sending
     */
    private DatagramSocket clientSocket;
    private int CLIENT_PORT;

    /*
     * Widgets for dest address, message text, send button.
     */
    private EditText destinationHost, destinationPort, messageText;
    private Button sendButton;

    /*
     * Called when the activity is first created.
     */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);

        CLIENT_PORT = DEFAULT_CLIENT_PORT;
        CLIENT_NAME = DEFAULT_CLIENT_NAME;

        /**
         * Let's be clear, this is a HACK to allow you to do network communication on the main thread.
         * This WILL cause an ANR, and is only provided to simplify the pedagogy.  We will see how to do
         * this right in a future assignment (using a Service managing background threads).
         */
        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);

        // TODO initialize the UI.
        destinationHost = (EditText)findViewById(R.id.destination_host);
        destinationPort = (EditText)findViewById(R.id.destination_port);
        messageText     = (EditText)findViewById(R.id.message_text);
        sendButton      = (Button)findViewById(R.id.send_button);

        sendButton.setOnClickListener(this);
        // End todo

        try {

            clientSocket = new DatagramSocket(CLIENT_PORT);

        } catch (Exception e) {
            Log.e(TAG, "Cannot open socket: " + e.getMessage(), e);
            return;
        }
    }

    /*
     * Callback for the SEND button.
     */
    public void onClick(View v) {
        try {
            /*
             * On the emulator, which does not support WIFI stack, we'll send to
             * (an AVD alias for) the host loopback interface, with the server
             * port on the host redirected to the server port on the server AVD.
             */

            InetAddress destAddr = InetAddress.getByName(destinationHost.getText().toString());
            int destPort         = Integer.parseInt(destinationPort.getText().toString());
            byte[] sendData      = new byte[1024];  // Combine sender and message text; default encoding is UTF-8

            // TODO get data from UI
            String message = CLIENT_NAME +","+messageText.getText().toString();
            sendData = message.getBytes();
            // End todo

            DatagramPacket sendPacket = new DatagramPacket(sendData, sendData.length, destAddr, destPort);

            clientSocket.send(sendPacket);
            Log.i(TAG, "Sent packet: " +sendData.toString());

        } catch (UnknownHostException e) {
            Log.e(TAG, "Unknown host exception: ", e);
        } catch (IOException e) {
            Log.e(TAG, "IO exception: ", e);
        }

        messageText.setText("");
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        super.onCreateOptionsMenu(menu);
        // TODO provide ADD, DELETE and CHECKOUT options
        getMenuInflater().inflate(R.menu.chat_client_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        super.onOptionsItemSelected(item);
        // TODO

        switch(item.getItemId()){
            case android.R.id.home:
                finish();
                break;

            case R.id.client_name_menu:  // Define Client Name as preference or shared preference
                Intent prefIntent = new Intent(getApplicationContext(), Settings.class);
                startActivityForResult(prefIntent, PREFERENCES);
                return true;
        }
        return false;
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode,
                                    Intent intent) {
        super.onActivityResult(requestCode, resultCode, intent);
        // TODO Handle results from the Search and Checkout activities.

        if(requestCode == PREFERENCES){
            if(resultCode == RESULT_OK){
                CLIENT_NAME = (String)intent.getExtras().get(constants.saveClientNamePreferences);
                Log.i(TAG, "client name = "+CLIENT_NAME);
            }else if(resultCode == RESULT_CANCELED){
                CLIENT_NAME = DEFAULT_CLIENT_NAME;
                Toast.makeText(this,"Client Name Set to Default",Toast.LENGTH_SHORT).show();
            }
        }
    }

}