package edu.stevens.cs522.chat.oneway.server.databases;


import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import edu.stevens.cs522.chat.oneway.server.contracts.MessageContract;
import edu.stevens.cs522.chat.oneway.server.contracts.PeerContract;
import edu.stevens.cs522.chat.oneway.server.entity.Peer;

/**
 * Created by DV6 on 2/13/2016.
 */
public class CartDbAdapter {

    final static public String TAG = CartDbAdapter.class.getCanonicalName();

    private static final String DATABASE_NAME = "peermessage.db";
    private static final int DATABASE_VERSION = 12;

    private static final String PEERS_TABLE = "peers";
    private static final String MESSAGE_TABLE = "messages";

    private static final String PEER_ID = PeerContract.ID;
    private static final String NAME = PeerContract.NAME;
    private static final String ADDRESS = PeerContract.ADDRESS;
    private static final String PORT = PeerContract.PORT;

    private static final String MESSAGE_ID = MessageContract.ID;
    private static final String MESSAGE_TEXT = MessageContract.MESSAGE_TEXT;
    private static final String SENDER = MessageContract.SENDER;
    private static final String PEER_FK = "peer_fk";

    private static final String PEER_MESSAGES = "peer_messages_view";

    private static final String DATABASE_CREATE_PEER ="CREATE TABLE "+PEERS_TABLE+" ("+ PEER_ID +" integer primary key autoincrement,"+
            NAME+" text not null,"+ADDRESS+" text not null,"+PORT+" integer);";

    private static final String DATABASE_CREATE_MESSAGE = "CREATE TABLE "+MESSAGE_TABLE+" ("+ MESSAGE_ID +" integer primary key autoincrement,"+
            MESSAGE_TEXT+" text,"+SENDER+" text,"+PEER_FK+" integer, foreign key ("+PEER_FK+") references "+PEERS_TABLE+
            "("+ PEER_ID +") on delete cascade);";

    public static String INDEX = "CREATE INDEX MessagesPeerIndex on "+MESSAGE_TABLE+"("+PEER_FK+");";

    public static String CREATE_VIEW = "CREATE VIEW "+PEER_MESSAGES+" as select "+PEERS_TABLE+"."+NAME+","+MESSAGE_TEXT+","+PEERS_TABLE+"."+PEER_ID +" from "+PEERS_TABLE+
            " join "+MESSAGE_TABLE+" on "+PEERS_TABLE+"."+ PEER_ID +"="+MESSAGE_TABLE+"."+PEER_FK+";";

    public static String row_id = "select last_insert_rowid() from "+PEERS_TABLE;

    private SQLiteDatabase sqlDB;
    private Context context;
    DatabaseHelper dbHelper;
    Cursor c;

    public CartDbAdapter(Context _context){
        context = _context;
        dbHelper = new DatabaseHelper(context);
    }

    private static class DatabaseHelper extends SQLiteOpenHelper {

        public DatabaseHelper(Context c){
            super(c,DATABASE_NAME,null,DATABASE_VERSION);
        }
        public void onCreate(SQLiteDatabase database) {
            database.execSQL(DATABASE_CREATE_PEER);
            database.execSQL(DATABASE_CREATE_MESSAGE);
            database.execSQL(CREATE_VIEW);
            //database.execSQL("DROP DATABASE IF EXISTS peers");
            //database.execSQL("DROP DATABASE IF EXISTS chatapp29");
        }
        public void onUpgrade(SQLiteDatabase database,int oldVersion,int newVersion){
            Log.w(DatabaseHelper.class.getName(),
                    "Upgrading database from version " + oldVersion + " to "
                            + newVersion + ", which will destroy all old data");
            database.execSQL("DROP TABLE IF EXISTS "+PEERS_TABLE);
            database.execSQL("DROP TABLE IF EXISTS "+MESSAGE_TABLE);
            database.execSQL("DROP VIEW IF EXISTS "+PEER_MESSAGES);
            onCreate(database);
        }
    }

    public CartDbAdapter open() throws SQLException {
        sqlDB = dbHelper.getWritableDatabase();
        sqlDB.execSQL("PRAGMA foreign_keys=ON;");
        return this;
    }

    public Cursor fetchAllMessages(){
        String[] ch =  {NAME,MESSAGE_TEXT};
        Log.e(TAG, PEER_MESSAGES + ch[0] + " " + ch[1] + " ");
        return sqlDB.query(PEER_MESSAGES,new String[]{NAME,MESSAGE_TEXT, PEER_ID},null,null,null,null,null);
    }

    public Cursor fetchAllPeers(){
        return sqlDB.query(PEERS_TABLE, new String[]{PEER_ID,NAME,ADDRESS,PORT}, null, null, null, null, null);
    }

    public Cursor fetchMessagesByPeer(Peer peer) {
        Log.i(TAG+"_fetchMessage", "in fetchMessageByPeer: "+peer.id+" ,"+peer.name);
        //return sqlDB.query(MESSAGE_TABLE, new String[]{MESSAGE_TEXT}, PEER_FK+"="+peer.id, null, null, null, null);
        //return sqlDB.query(MESSAGE_TABLE, new String[]{MESSAGE_ID,MESSAGE_TEXT,SENDER,PEER_FK}, null, null, null, null, null);
        Cursor c = sqlDB.rawQuery("SELECT "+MESSAGE_TABLE+"."+MESSAGE_ID+" ,"+MESSAGE_TEXT+" ,"+SENDER+" ,"+PEER_FK+" ,"+PEER_FK+" as _id FROM "+MESSAGE_TABLE+" WHERE "+PEER_FK+" = "+peer.id+" AND "+SENDER+" = '"+peer.name+"' ", null);
        return c;
    }

    public long getPeerID(Peer peer){
        String query = "SELECT "+PeerContract.ID+" ,"+NAME+" ,"+ADDRESS+" ,"+PORT+" FROM "+PEERS_TABLE+" WHERE "+PEERS_TABLE+"."+NAME+" = '"+peer.name+"' and "+ADDRESS+" = '"+peer.address.toString()+"'";
        Log.i(TAG,query);
        String[] selectionArgs = null;
        Cursor cursor = sqlDB.rawQuery(query,selectionArgs);
        if(cursor != null){
            if(cursor.moveToFirst()){
                Peer p = new Peer(cursor);
                Log.i(TAG,query+" ,"+p.id);
                return p.id;
            }
        }
        Log.i(TAG,query+" ,-1");
        return -1;
    }
    public void persist(Peer peer,String message){
        ContentValues contentValues = new ContentValues();
        long peerID = getPeerID(peer);
        if(peerID == -1){
            contentValues.put(NAME, peer.name);
            contentValues.put(ADDRESS, peer.address.toString());
            contentValues.put(PORT, peer.port);

            sqlDB.insert(PEERS_TABLE, null, contentValues);

            Log.i(TAG, PEERS_TABLE + "  ," + peer.name + "  ," + peer.address.toString() + " ," + peer.port);
            contentValues.clear();

            Cursor cursor = sqlDB.rawQuery(row_id, null);
            cursor.moveToFirst();
            peerID = cursor.getInt(0);
        }

        contentValues.put(MESSAGE_TEXT, message);
        contentValues.put(SENDER, peer.name);
        contentValues.put(PEER_FK, peerID);

        sqlDB.insert(MESSAGE_TABLE, null, contentValues);

        Log.i(TAG, MESSAGE_TABLE + "  ," + message + " ," + peer.name + "  ." + peerID);
        contentValues.clear();
    }

    public Peer fetchByName(String name){
        Cursor cur = sqlDB.query(PEERS_TABLE,new String[]{PeerContract.ID,PeerContract.NAME,PeerContract.ADDRESS,PeerContract.PORT},
                PeerContract.NAME+"=?",new String[]{name},null,null,null);
        if(cur!=null)
            cur.moveToFirst();

        Peer peer = new Peer(cur);
        return peer;

    }

    public void close(){
        sqlDB.close();
    }
}
