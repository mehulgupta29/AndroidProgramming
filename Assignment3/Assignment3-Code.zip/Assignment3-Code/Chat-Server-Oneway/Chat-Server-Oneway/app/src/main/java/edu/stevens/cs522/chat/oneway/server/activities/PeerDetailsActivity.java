package edu.stevens.cs522.chat.oneway.server.activities;

import android.app.Activity;
import android.database.Cursor;
import android.os.Bundle;
import android.util.Log;
import android.widget.ListView;
import android.widget.SimpleCursorAdapter;
import android.widget.TextView;

import edu.stevens.cs522.chat.oneway.server.R;
import edu.stevens.cs522.chat.oneway.server.contracts.MessageContract;
import edu.stevens.cs522.chat.oneway.server.databases.CartDbAdapter;
import edu.stevens.cs522.chat.oneway.server.entity.Message;
import edu.stevens.cs522.chat.oneway.server.entity.Peer;

public class PeerDetailsActivity extends Activity {

    SimpleCursorAdapter simpleCursorAdapter;
    private CartDbAdapter cartDbAdapter;
    Cursor cursor;

    public static TextView nameTV,hostNameTV,portTV;
    public static  ListView messageLV;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.peer_details);

        Peer peer = getIntent().getExtras().getParcelable(constants.PEER);
        Log.i("peer_details", peer.name + " ," + peer.address.toString() + " ," + peer.port);

        nameTV = (TextView)findViewById(R.id.details_peer_name);
        hostNameTV = (TextView)findViewById(R.id.details_peer_hostname);
        portTV = (TextView)findViewById(R.id.details_peer_port);

        String name = peer.name, hostName = peer.address.toString().substring(1), port = ""+peer.port;
        Log.i("peer_details_b_setTxt", name + " ," + hostName + " ," + port);
        if(nameTV == null){
            Log.i("peer_details", "NameTV is null");
        }
        if(hostNameTV == null){
            Log.i("peer_details", "hostNameTV is null");
        }
        if(portTV == null){
            Log.i("peer_details", "portTV is null");
        }
        if(nameTV != null && hostNameTV != null && portTV != null) {
            nameTV.setText(name);
            hostNameTV.setText(hostName);
            portTV.setText(port);
            Log.i("peer_details_a_setTxt", name + " ," + hostName + " ," + port);
        }
        Log.i("peer_details_a_setTxt", "preaping list view");

        cartDbAdapter = new CartDbAdapter(this);
        cartDbAdapter.open();
        cursor = cartDbAdapter.fetchMessagesByPeer(peer);

       /* if(cursor.moveToFirst()){
            Message m = new Message(cursor);
            Log.i("_cur_res", m.messageText);
        }
        cursor.moveToFirst();*/


        messageLV = (ListView)findViewById(R.id.peer_message_list_details);
        String [] from = {MessageContract.MESSAGE_TEXT};
        int [] to ={R.id.display};
        simpleCursorAdapter = new SimpleCursorAdapter(this, R.layout.message, cursor, from, to);
        messageLV.setAdapter(simpleCursorAdapter);

        //simpleCursorAdapter.changeCursor(cursor);
        //simpleCursorAdapter.notifyDataSetChanged();

        registerForContextMenu(messageLV);
    }
}
