package edu.stevens.cs522.chat.oneway.server.contracts;

import android.content.ContentValues;
import android.database.Cursor;
import android.util.Log;

/**
 * Created by DV6 on 2/13/2016.
 */
public class MessageContract {
    public static final String ID = "id";
    public static final String MESSAGE_TEXT = "messageText";
    public static final String SENDER = "sender";

    public static String getId(Cursor cursor) {
        return cursor.getString(cursor.getColumnIndexOrThrow(ID));
    }
    public static void putId(ContentValues contentValues,String id){
        contentValues.put(ID,id);
    }
    public static String getMessageText(Cursor cursor){
        Log.i("fetchMessage",": "+cursor.getColumnIndexOrThrow(MESSAGE_TEXT));
        return cursor.getString(cursor.getColumnIndexOrThrow(MESSAGE_TEXT));
    }
    public static void putMessageText(ContentValues contentValues,String messageText){
        contentValues.put(MESSAGE_TEXT,messageText);
    }
    public static String getSender(Cursor cursor){
        return cursor.getString(cursor.getColumnIndexOrThrow(SENDER));
    }
    public static void putSender(ContentValues contentValues,String sender){
        contentValues.put(SENDER,sender);
    }
}
