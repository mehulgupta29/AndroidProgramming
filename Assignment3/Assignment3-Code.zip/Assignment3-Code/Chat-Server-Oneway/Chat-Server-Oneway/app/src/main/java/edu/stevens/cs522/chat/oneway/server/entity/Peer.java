package edu.stevens.cs522.chat.oneway.server.entity;

import android.database.Cursor;
import android.os.Parcel;
import android.os.Parcelable;
import android.util.Log;

import java.net.InetAddress;
import java.net.UnknownHostException;

import edu.stevens.cs522.chat.oneway.server.R;
import edu.stevens.cs522.chat.oneway.server.contracts.MessageContract;
import edu.stevens.cs522.chat.oneway.server.contracts.PeerContract;

/**
 * Created by DV6 on 2/13/2016.
 */
public class Peer implements Parcelable{

    public long id;
    public String name;
    public InetAddress address;
    public int port;

    public Peer(String name,InetAddress addr,int port ){
        this.name = name;
        this.address = addr;
        this.port = port;
    }

    public Peer(Cursor cursor){
        this.id = Long.parseLong(PeerContract.getId(cursor));
        this.name = PeerContract.getName(cursor);
        try {
            Log.i("Peer_cursor",PeerContract.getAddress(cursor));
            this.address = InetAddress.getByName(PeerContract.getAddress(cursor).substring(1));
        }catch (UnknownHostException e){
            Log.i("Peer", "Unknown Host Exception");
        }
        this.port=Integer.parseInt(PeerContract.getPort(cursor));
        Log.i("Peer_cursor", PeerContract.getPort(cursor)+" ,"+this.port);
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel dest, int flags) {
        dest.writeLong(this.id);
        dest.writeString(this.name);
        dest.writeSerializable(this.address);
        dest.writeInt(this.port);
    }

    protected Peer(Parcel in) {
        this.id = in.readLong();
        this.name = in.readString();
        this.address = (InetAddress) in.readSerializable();
        this.port = in.readInt();
    }

    public static final Creator<Peer> CREATOR = new Creator<Peer>() {
        public Peer createFromParcel(Parcel source) {
            return new Peer(source);
        }

        public Peer[] newArray(int size) {
            return new Peer[size];
        }
    };
}

