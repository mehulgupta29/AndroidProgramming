package edu.stevens.cs522.chat.oneway.server.contracts;

import android.content.ContentValues;
import android.database.Cursor;

/**
 * Created by DV6 on 2/13/2016.
 */
public class PeerContract {

    public static final String ID = "_id";
    public static final String NAME = "name";
    public static final String ADDRESS = "address";
    public static final String PORT = "port";

    public static String getId(Cursor cursor) {
        return cursor.getString(cursor.getColumnIndexOrThrow(ID));
    }
    public static void putId(ContentValues contentValues,String id){
        contentValues.put(ID, id);
    }
    public static String getName(Cursor cursor){
        return cursor.getString(cursor.getColumnIndexOrThrow(NAME));
    }
    public static void putName(ContentValues contentValues,String name){
        contentValues.put(NAME,name);
    }
    public static String getAddress(Cursor cursor){
        return cursor.getString(cursor.getColumnIndexOrThrow(ADDRESS));
    }
    public static void putAddress(ContentValues contentValues,String address){
        contentValues.put(ADDRESS,address);
    }
    public static String getPort(Cursor cursor){
        return cursor.getString(cursor.getColumnIndexOrThrow(PORT));
    }
    public static void putPort(ContentValues contentValues,String port){
        contentValues.put(PORT,port);
    }

}
