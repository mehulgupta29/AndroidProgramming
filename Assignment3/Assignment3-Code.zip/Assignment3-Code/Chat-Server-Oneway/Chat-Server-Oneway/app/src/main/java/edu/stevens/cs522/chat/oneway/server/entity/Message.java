package edu.stevens.cs522.chat.oneway.server.entity;

import android.database.Cursor;
import android.os.Parcel;
import android.os.Parcelable;

import edu.stevens.cs522.chat.oneway.server.contracts.MessageContract;

/**
 * Created by DV6 on 2/13/2016.
 */
public class Message implements Parcelable{
    public long id;
    public String messageText;
    public String sender;

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel dest, int flags) {
        dest.writeLong(this.id);
        dest.writeString(this.messageText);
        dest.writeString(this.sender);
    }

    public Message() {
    }

    public Message(long id, String messageText, String sender) {
        this.id = id;
        this.messageText = messageText;
        this.sender = sender;
    }

    protected Message(Parcel in) {
        this.id = in.readLong();
        this.messageText = in.readString();
        this.sender = in.readString();
    }

    public Message(Cursor cursor){
        this.id = Long.parseLong(MessageContract.getId(cursor));
        this.messageText = MessageContract.getMessageText(cursor);
        this.sender = MessageContract.getSender(cursor);
    }

    public static final Creator<Message> CREATOR = new Creator<Message>() {
        public Message createFromParcel(Parcel source) {
            return new Message(source);
        }

        public Message[] newArray(int size) {
            return new Message[size];
        }
    };


}
