package edu.stevens.cs522.chat.oneway.server.activities;

import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.os.StrictMode;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ListView;
import android.widget.SimpleCursorAdapter;
import android.widget.Toast;

import edu.stevens.cs522.chat.oneway.server.R;
import edu.stevens.cs522.chat.oneway.server.contracts.MessageContract;
import edu.stevens.cs522.chat.oneway.server.contracts.PeerContract;
import edu.stevens.cs522.chat.oneway.server.databases.CartDbAdapter;
import edu.stevens.cs522.chat.oneway.server.entity.Peer;

public class ChatServer extends Activity implements OnClickListener {

    final static public String TAG = ChatServer.class.getCanonicalName();
    final static public int PEERS_LIST_REQUEST = 1;
    /*
     * Socket used both for sending and receiving
     */
    private DatagramSocket serverSocket;

    /*
     * True as long as we don't get socket errors
     */
    private boolean socketOK = true;

    private CartDbAdapter cartDbAdapter;
    Cursor cursor;
    SimpleCursorAdapter simpleCursorAdapter;

    Button next;

    /*
     * Called when the activity is first created.
     */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        if(cartDbAdapter!=null)
            cursor = cartDbAdapter.fetchAllMessages();
        else{
            cartDbAdapter = new CartDbAdapter(this);
            cartDbAdapter.open();
            cursor = cartDbAdapter.fetchAllMessages();
        }

        setContentView(R.layout.main);

        ListView list = (ListView)findViewById(R.id.msgList);
        String [] from = {PeerContract.NAME, MessageContract.MESSAGE_TEXT};
        int [] to ={R.id.sender,R.id.message};
        simpleCursorAdapter = new SimpleCursorAdapter(this,R.layout.message_layout,cursor,from,to);
        list.setAdapter(simpleCursorAdapter);

        /**
         * Let's be clear, this is a HACK to allow you to do network communication on the main thread.
         * This WILL cause an ANR, and is only provided to simplify the pedagogy.  We will see how to do
         * this right in a future assignment (using a Service managing background threads).
         */
        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);

        try {
            /*
             * Get port information from the resources.
             */
            int port = Integer.parseInt(this.getString(R.string.app_port));
            serverSocket = new DatagramSocket(port);
            //initialize
            if(serverSocket == null){
                serverSocket = new DatagramSocket(null);
                serverSocket.setReuseAddress(true);
                serverSocket.bind(new InetSocketAddress(port));
            }
        } catch (Exception e) {
            Log.e(TAG, "Cannot open socket" + e.getMessage());
            return;
        }

        next = (Button)findViewById(R.id.next);
        next.setOnClickListener(this);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        super.onCreateOptionsMenu(menu);
        // TODO provide ADD, DELETE and CHECKOUT options
        getMenuInflater().inflate(R.menu.chat_server_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        super.onOptionsItemSelected(item);
        // TODO

        switch(item.getItemId()){
            case android.R.id.home:
                finish();
                break;

            case R.id.peers_list_menu:  // Define Client Name as preference or shared preference
                Intent peersIntent = new Intent(getApplicationContext(), PeersListActivity.class);
                startActivity(peersIntent);
                return true;
        }
        return false;
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode,
                                    Intent intent) {
        super.onActivityResult(requestCode, resultCode, intent);
        // TODO Handle results from the Search and Checkout activities.
/*
        if(requestCode == PREFERENCES){
            if(resultCode == RESULT_OK){
                CLIENT_NAME = (String)intent.getExtras().get(constants.saveClientNamePreferences);
                Log.i(TAG, "client name = "+CLIENT_NAME);
            }else if(resultCode == RESULT_CANCELED){
                CLIENT_NAME = DEFAULT_CLIENT_NAME;
                Toast.makeText(this, "Client Name Set to Default", Toast.LENGTH_SHORT).show();
            }
        }*/
    }


    public void onClick(View v) {
        byte[] receiveData = new byte[1024];
        switch (v.getId()){
            case R.id.next:
                DatagramPacket receivePacket = new DatagramPacket(receiveData, receiveData.length);
                try {

                        serverSocket.receive(receivePacket);
                        Log.i(TAG, "Received a packet");

                        InetAddress sourceIPAddress = receivePacket.getAddress();
                        Log.i(TAG, "Source IP Address: " + sourceIPAddress);

                        /*
                         * TODO: Extract sender and receiver from message and display.
                         */

                        receiveData = receivePacket.getData();
                        String[] fromClient = new String(receiveData, 0, receivePacket.getLength()).split(",");
                        String sender = fromClient[0];
                        String message = fromClient[1];
                        Log.i(TAG, sender+ "," +message);

                        CartDbAdapter dbAdapter = new CartDbAdapter(this);
                        dbAdapter.open();

                        Peer peer = new Peer(sender,sourceIPAddress,receivePacket.getPort());
                        dbAdapter.persist(peer,message);
                        cursor.requery();
                        simpleCursorAdapter.changeCursor(cursor);
                        simpleCursorAdapter.notifyDataSetChanged();

                        dbAdapter.close();


                } catch (Exception e) {
                    Log.e(TAG, "Problems receiving packet: " + e.getMessage());
                    socketOK = false;
                }
        }
    }

    @Override
    public void onStop(){
        closeSocket();
        super.onStop();
    }

    /*
     * Close the socket before exiting application
     */
    public void closeSocket() {
        //serverSocket.close();
    }

    /*
     * If the socket is OK, then it's running
     */
    boolean socketIsOK() {
        return socketOK;
    }

}