package edu.stevens.cs522.chat.oneway.server.activities;


import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.SimpleCursorAdapter;

import edu.stevens.cs522.chat.oneway.server.R;
import edu.stevens.cs522.chat.oneway.server.databases.CartDbAdapter;
import edu.stevens.cs522.chat.oneway.server.entity.Peer;

public class PeersListActivity extends Activity {

    final static public String TAG = ChatServer.class.getCanonicalName();

    SimpleCursorAdapter simpleCursorAdapter;
    private CartDbAdapter cartDbAdapter;
    Cursor cursor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        Log.i(TAG,"In PeersListActivity");

        if(cartDbAdapter!=null)
            cursor = cartDbAdapter.fetchAllPeers();
        else{
            cartDbAdapter = new CartDbAdapter(this);
            cartDbAdapter.open();
            cursor = cartDbAdapter.fetchAllPeers();
        }

        setContentView(R.layout.activity_peers_list);

        ListView peerList = (ListView)findViewById(R.id.peers_list);
        String [] from = {"name"};
        int [] to ={R.id.sender};
        simpleCursorAdapter = new SimpleCursorAdapter(this,R.layout.message_layout,cursor,from,to);
        peerList.setAdapter(simpleCursorAdapter);

        simpleCursorAdapter.changeCursor(cursor);
        simpleCursorAdapter.notifyDataSetChanged();

        peerList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent intent = new Intent(getApplicationContext(), PeerDetailsActivity.class);
                cursor.moveToPosition(position);
                Peer displayPeer = new Peer(cursor);
                Log.i(TAG,displayPeer.name+" ,"+displayPeer.address.toString()+" ,"+displayPeer.port);
                intent.putExtra(constants.PEER, displayPeer);
                startActivity(intent);
            }
        });

        registerForContextMenu(peerList);
        peerList.setItemsCanFocus(true);
    }
}
