package edu.stevens.cs522.bookstore.activities;

import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.regex.Pattern;

import edu.stevens.cs522.bookstore.R;
import edu.stevens.cs522.bookstore.contracts.BookContract;
import edu.stevens.cs522.bookstore.entities.Author;
import edu.stevens.cs522.bookstore.entities.Book;

public class AddBookActivity extends Activity{
	
	// Use this as the key to return the book details as a Parcelable extra in the result intent.
    private static String title,author,isbn,price;
	
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.add_book);
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		super.onCreateOptionsMenu(menu);
		// TODO provide SEARCH and CANCEL options
        getMenuInflater().inflate(R.menu.add_book_menu, menu);
		return true;
	}


	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		super.onOptionsItemSelected(item);
		// TODO

        Intent intentData = new Intent();
        title = ((EditText)findViewById(R.id.search_title)).getText().toString();
        author = ((EditText)findViewById(R.id.search_author)).getText().toString();
        isbn = ((EditText)findViewById(R.id.search_isbn)).getText().toString();
        price = ((EditText)findViewById(R.id.search_price)).getText().toString();

		switch(item.getItemId()){
            case R.id.add:  //ADD: Add book ,authors in the database
                Book book = new Book(0, title, generateAuthors(author), isbn, price);
                intentData.putExtra(constants.book, book);
                intentData.putExtra(constants.button, "ADD");
                setResult(Activity.RESULT_OK, intentData);
                finish();
                break;

            case R.id.search:   // SEARCH: return the book details to the BookStore activity
                Book bookDeatils = searchBook(title, generateAuthors(author), isbn, price);
                Log.i("Details", bookDeatils.title);
                intentData.putExtra(constants.Detail, bookDeatils);
                intentData.putExtra(constants.button, "SEARCH");
                setResult(Activity.RESULT_OK, intentData);
                finish();
                break;

            case R.id.cancel:   // CANCEL: cancel the search request
                setResult(Activity.RESULT_CANCELED, intentData);
                finish();
                return true;

            case R.id.home:
                finish();
                return true;
        }
		return false;
	}

    public static final char SEPARATOR_CHAR = ',';
    private static final Pattern SEPARATOR =   Pattern.compile(Character.toString(SEPARATOR_CHAR), Pattern.LITERAL);
    public static String[] readStringArray(String in) {   return SEPARATOR.split(in);}

    public Author[] generateAuthors(String authorEV){
        String [] authorArray = authorEV.split(",");
        Author[] authors = Author.CREATOR.newArray(authorArray.length);
        int index = 0;
        for(String author : authorArray){
            Author a = null;
            String [] authorFullName = author.split("\\s+");
            if(authorFullName.length == 1){
                a = new Author(authorFullName[0]);
            }else if(authorFullName.length == 2){
                a = new Author(authorFullName[0], authorFullName[1]);
            }else if(authorFullName.length == 3){
                a = new Author(authorFullName[0], authorFullName[1], authorFullName[2]);
            }else{
                Log.i("Array_AddBookActivity", "Error in authors");
            }
            authors[index] = a;
            index++;
        }
        return authors;
    }

    public Book searchBook(String title, Author[] authArray, String isbn, String price){
		/*
		 * Search for the specified book.
		 */
		// TODO Just build a Book object with the search criteria and return that.
        Book book = new Book(0, title, authArray, isbn, price);
        return book;
    }
}