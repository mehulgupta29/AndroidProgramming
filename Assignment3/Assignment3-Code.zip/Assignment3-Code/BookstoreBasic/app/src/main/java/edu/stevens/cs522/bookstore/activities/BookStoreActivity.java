package edu.stevens.cs522.bookstore.activities;

import java.sql.SQLException;
import java.util.ArrayList;

import android.app.ListActivity;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.util.Log;
import android.util.SparseBooleanArray;
import android.view.ActionMode;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.CursorAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import edu.stevens.cs522.bookstore.R;
import edu.stevens.cs522.bookstore.contracts.BookContract;
import edu.stevens.cs522.bookstore.databases.CartDbAdapter;
import edu.stevens.cs522.bookstore.entities.Book;

public class BookStoreActivity extends ListActivity {
	
	// Use this when logging errors and warnings.
	@SuppressWarnings("unused")
	//private static final String TAG = BookStoreActivity.class.getCanonicalName();
	private static final String TAG = "BookStoreBasics_";
	
	// These are request codes for subactivity request calls
	static final private int ADD_REQUEST = 1;
	
	@SuppressWarnings("unused")
	static final private int CHECKOUT_REQUEST = ADD_REQUEST + 1;

	// There is a reason this must be an ArrayList instead of a List.
	@SuppressWarnings("unused")
	private ArrayList<Book> shoppingCart = new ArrayList<Book>();	//data source
    private ListView bookStoreListView;	//ListView
    private static final String BOOK_DETAILS = "Book_Details";

    //SimpleCursor Adapter
    private CartDbAdapter cartDbAdapter;
    Cursor cursor;
    private custCursorAdapter custAdapter;


	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

        // TODO check if there is saved UI state, and if so, restore it (i.e. the cart contents)
        /*if(savedInstanceState != null){
            shoppingCart = savedInstanceState.getParcelableArrayList("list");
        }*/
        if(cartDbAdapter != null){
            cursor = cartDbAdapter.fetchAllBooks();
        }else{
            try {
                cartDbAdapter = new CartDbAdapter(this);
                cartDbAdapter.open();
                cursor = cartDbAdapter.fetchAllBooks();
            }catch(SQLException sqlE){
                Log.e(TAG, "Error in opening new DB connection, while restoring the savedInstance State");
            }
        }

        // TODO Set the layout (use cart.xml layout)
		setContentView(R.layout.cart);

        // TODO use an array adapter to display the cart contents.
        bookStoreListView = (ListView)findViewById(android.R.id.list);
        custAdapter = new custCursorAdapter(this, cursor);
        bookStoreListView.setAdapter(custAdapter);

        // For Contextual Action Menu
        bookStoreListView.setChoiceMode(ListView.CHOICE_MODE_MULTIPLE_MODAL);
        bookStoreListView.setMultiChoiceModeListener(new AbsListView.MultiChoiceModeListener() {
            @Override
            public void onItemCheckedStateChanged(ActionMode mode, int position, long id, boolean checked) {
                mode.setTitle(bookStoreListView.getCheckedItemCount() + " selected Items");
            }

            @Override
            public boolean onCreateActionMode(ActionMode mode, Menu menu) {
                Log.i(TAG, "creating action mode");
                mode.getMenuInflater().inflate(R.menu.context_action_bar_menu, menu);
                return true;
            }

            @Override
            public boolean onPrepareActionMode(ActionMode mode, Menu menu) {
                return false;
            }

            @Override
            public boolean onActionItemClicked(ActionMode mode, MenuItem item) {
                switch (item.getItemId()) {
                    case R.id.cab_menu_delete:
                        try{
                            Log.i(TAG, "action item delete clicked");
                            deleteSelectedBooks();
                            Toast.makeText(getBaseContext(), "Record deleted", Toast.LENGTH_SHORT).show();
                            mode.finish();
                            return true;
                        }catch(SQLException sqlE){
                            sqlE.printStackTrace();
                        }finally{return false;}

                    case R.id.cab_menu_details:
                        SparseBooleanArray checked = bookStoreListView.getCheckedItemPositions();
                        for(int i =0; i < checked.size(); i++){
                            if(checked.valueAt(i) == true) {
                                Book theSelectedBook = new Book((Cursor)bookStoreListView.getItemAtPosition(checked.keyAt(i)));
                                Intent addIntent = new Intent(getApplicationContext(), DetailsActivity.class);
                                addIntent.putExtra(constants.Detail, theSelectedBook);
                                startActivity(addIntent);
                            }
                        }
                        return  true;

                    default:
                        return false;
                }
            }

            @Override
            public void onDestroyActionMode(ActionMode mode) {
                Log.i(TAG, "destroying action mode");
            }
        });

        bookStoreListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                Intent intent = new Intent(getApplicationContext(), DetailsActivity.class);
                cursor.moveToPosition(position);
                Book displayBook = new Book(cursor);
                intent.putExtra(constants.Detail, displayBook);
                startActivity(intent);
            }
        });

        registerForContextMenu(bookStoreListView);
        bookStoreListView.setItemsCanFocus(true);
    }

    private void deleteSelectedBooks() throws SQLException{
        SparseBooleanArray checked = bookStoreListView.getCheckedItemPositions();

        Book [] books = new Book[checked.size()];
        for(int i = 0; i < checked.size(); i++){
            if(checked.valueAt(i) == true){
                cursor.moveToPosition(i);
                Book b = new Book(cursor);
                cartDbAdapter.delete(b);
                cursor.requery();
                custAdapter.changeCursor(cursor);
                custAdapter.notifyDataSetChanged();
            }
        }
        custAdapter.changeCursor(cursor);
        custAdapter.notifyDataSetChanged();
    }

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		super.onCreateOptionsMenu(menu);
		// TODO provide ADD, DELETE and CHECKOUT options
        getMenuInflater().inflate(R.menu.bookstore_menu, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		super.onOptionsItemSelected(item);
		// TODO

        switch(item.getItemId()){
            case android.R.id.home:
                finish();
                break;

            case R.id.add:  // ADD provide the UI for adding a book
                Intent addIntent = new Intent(getApplicationContext(), AddBookActivity.class);
                startActivityForResult(addIntent, ADD_REQUEST);
                return true;

            case R.id.details:   // DELETE delete the currently selected book
                if(cursor == null){
                    Toast.makeText(this, "Cart is Empty! Nothing to Display!", Toast.LENGTH_LONG).show();
                }else{
                    Intent detailsIntent = new Intent(getApplicationContext(), DetailsActivity.class);
                    cursor.moveToPosition(0);
                    Book displayBook = new Book(cursor);
                    detailsIntent.putExtra(constants.Detail, displayBook);
                    startActivity(detailsIntent);
                }
                return true;

            case R.id.checkout: // CHECKOUT provide the UI for checking out
                if(cursor == null){
                    Toast.makeText(this, "Cart is Empty!!", Toast.LENGTH_LONG).show();
                }else{
                    Intent checkOutIntent = new Intent(getApplicationContext(), CheckoutActivity.class);
                    startActivityForResult(checkOutIntent, CHECKOUT_REQUEST);
                }
                return true;
        }
	return false;
	}

    @Override
    protected void onActivityResult(int requestCode, int resultCode,
                                    Intent intent) {
        super.onActivityResult(requestCode, resultCode, intent);
        // TODO Handle results from the Search and Checkout activities.

        Book book;
        StringBuffer str = new StringBuffer();

        if(requestCode == ADD_REQUEST){
            if(resultCode == RESULT_OK){
                String actionBtn = (String)intent.getExtras().get(constants.button);
                if(actionBtn.equalsIgnoreCase("ADD")){  // ADD: add the book that is returned to the shopping cart.
                    try{
                        book = intent.getExtras().getParcelable(constants.book);
                        cartDbAdapter.persist(book);
                        cursor.requery();
                        custAdapter.changeCursor(cursor);
                        custAdapter.notifyDataSetChanged();
                    }catch(SQLException sqlE){
                        Toast.makeText(getApplicationContext(), "Book not added", Toast.LENGTH_SHORT).show();
                    }
                }else if(actionBtn.equalsIgnoreCase("SEARCH")){ // SEARCH: Search the book in the shopping cart database: if found then show the book details, else return back to Main activity
                    try{
                        Book searchBook = intent.getExtras().getParcelable(constants.Detail);
                        int row_id = cartDbAdapter.searchBookByBookTitle(searchBook);
                        Book searchResult = cartDbAdapter.fetchBook(row_id);
                        Intent intentData = new Intent(getApplicationContext(), DetailsActivity.class);
                        intentData.putExtra(constants.Detail, searchResult);
                        startActivity(intentData);

                    }catch(Exception sqlE){
                        Toast.makeText(getApplicationContext(), "Book not searched", Toast.LENGTH_SHORT).show();
                    }
                }
            }else if(resultCode == RESULT_CANCELED){
                Toast.makeText(this,"AddBook Cancelled",Toast.LENGTH_SHORT).show();
            }
        }else if(requestCode == CHECKOUT_REQUEST){  // CHECKOUT: empty the shopping cart.
            if(resultCode == RESULT_OK){
                Toast.makeText(this, Integer.toString(cursor.getCount())+" books checked out", Toast.LENGTH_SHORT).show();
                cartDbAdapter.deleteAll();
                cursor.requery();
                custAdapter.notifyDataSetInvalidated();
                custAdapter.swapCursor(cursor);

            }else if(resultCode == RESULT_CANCELED){
                Toast.makeText(this,"Checkout Cancelled",Toast.LENGTH_SHORT).show();
            }
        }
    }

    @Override
	public void onSaveInstanceState(Bundle savedInstanceState) {
		// TODO save the shopping cart contents (which should be a list of parcelables).
		savedInstanceState.putParcelableArrayList(constants.list, shoppingCart);
        super.onSaveInstanceState(savedInstanceState);
	}


    private class custCursorAdapter extends CursorAdapter{
        public custCursorAdapter(Context context, Cursor cursor){
            super(context, cursor, 0);
        }

        @Override
        public View newView(Context context, Cursor cursor, ViewGroup parent) {
            return LayoutInflater.from(context).inflate(R.layout.cart_row, parent, false);
        }

        @Override
        public void bindView(View view, Context context, Cursor cursor) {
            TextView txtTitle = (TextView) view.findViewById(R.id.cart_row_title);
            txtTitle.setText(BookContract.getTitle(cursor));

            TextView txtAuthors = (TextView) view.findViewById(R.id.cart_row_author);
            txtAuthors.setText(BookContract.getAuthors(cursor));

            TextView txtIsbn = (TextView) view.findViewById(R.id.cart_row_isbn);
            txtIsbn.setText(BookContract.getIsbn(cursor));

            TextView txtPrice = (TextView) view.findViewById(R.id.cart_row_price);
            txtPrice.setText(BookContract.getPrice(cursor));
        }
    }

}