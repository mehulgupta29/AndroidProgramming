package edu.stevens.cs522.bookstore.contracts;

import android.content.ContentValues;
import android.database.Cursor;

/**
 * Created by DV6 on 2/7/2016.
 */
public class AuthorContract {

    public static final String _AUTHOR_ID = "author_id";
    public static final String FIRST_NAME = "first_name";
    public static final String MIDDLE_INITIAL = "middle_initial";
    public static final String LAST_NAME = "last_name";

    public static String getAuthorId(Cursor cursor){
        return cursor.getString(cursor.getColumnIndexOrThrow(_AUTHOR_ID));
    }
    public static void putAuthorId(ContentValues contentValues, String author_id){
        contentValues.put(_AUTHOR_ID, author_id);
    }
    public static String getFirstName(Cursor cursor){
        return cursor.getString(cursor.getColumnIndexOrThrow(FIRST_NAME));
    }
    public static void putFirstName(ContentValues contentValues, String first_name){
        contentValues.put(FIRST_NAME, first_name);
    }
    public static String getMiddleInitial(Cursor cursor){
        return cursor.getString(cursor.getColumnIndexOrThrow(MIDDLE_INITIAL));
    }
    public static void putMiddleInitial(ContentValues contentValues, String middle_initial){
        contentValues.put(MIDDLE_INITIAL, middle_initial);
    }
    public static String getLastName(Cursor cursor){
        return cursor.getString(cursor.getColumnIndexOrThrow(LAST_NAME));
    }
    public static void putLastName(ContentValues contentValues, String last_name){
        contentValues.put(LAST_NAME, last_name);
    }

}
