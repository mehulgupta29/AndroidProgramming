package edu.stevens.cs522.bookstore.activities;


import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;

import edu.stevens.cs522.bookstore.R;
import edu.stevens.cs522.bookstore.entities.Author;
import edu.stevens.cs522.bookstore.entities.Book;


public class DetailsActivity extends Activity {

    private static final String BOOK_DETAILS = "Book_Details";
    private TextView titleTV, authorsTV, priceTV, isbnTV;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_details);

        titleTV = (TextView)findViewById(R.id.detailsTitleValueTextView);
        authorsTV = (TextView)findViewById(R.id.detailsAuthorsValuesTextView);
        isbnTV = (TextView)findViewById(R.id.detailsISBNValuesTextView);
        priceTV = (TextView)findViewById(R.id.detailsPriceValueTextView);

        Book book = getIntent().getExtras().getParcelable(constants.Detail);
        titleTV.setText(book.getTitle());

        //DIsplay Authours
        Author[] authors = book.getAuthors();
        String authorStr = "";
        for(Author a : authors){
            if(a.middleInitial != null){
                authorStr += a.firstName+" "+a.middleInitial+" "+a.lastName;
            }else{
                authorStr += a.firstName+" "+a.lastName;
            }
            authorStr += "\n";
        }
        authorsTV.setText(authorStr);
        isbnTV.setText(book.getIsbn());
        priceTV.setText(book.getPrice());

        Log.i("DetailsActivity:  ", new Integer(book.id).toString() );
    }
}
