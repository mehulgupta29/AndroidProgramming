package edu.stevens.cs522.bookstore.contracts;

import android.content.ContentValues;
import android.database.Cursor;

/**
 * Created by DV6 on 2/7/2016.
 */
public class BookContract {
    public static final String _ID = "_id";
    public static final String TITLE = "title";
    public static final String AUTHORS = "authors";
    public static final String ISBN = "isbn";
    public static final String PRICE = "price";

    public static String getId(Cursor cursor){
        return cursor.getString(cursor.getColumnIndexOrThrow(_ID));
    }
    public static void putId(ContentValues contentValues, String id){
        contentValues.put(_ID, id);
    }
    public static String getTitle(Cursor cursor){
        return cursor.getString(cursor.getColumnIndexOrThrow(TITLE));
    }
    public static void putTitle(ContentValues contentValues, String title){
        contentValues.put(TITLE, title);
    }
    public static String getAuthors(Cursor cursor){
        return cursor.getString(cursor.getColumnIndexOrThrow(AUTHORS));
    }
    public static void putAuthors(ContentValues contentValues, String authors) {
        contentValues.put(AUTHORS, authors);
    }
    public static String getIsbn(Cursor cursor){
        return cursor.getString(cursor.getColumnIndexOrThrow(ISBN));
    }
    public static void putIsbn(ContentValues contentValues, String isbn){
        contentValues.put(ISBN, isbn);
    }
    public static String getPrice(Cursor cursor){
        return cursor.getString(cursor.getColumnIndexOrThrow(PRICE));
    }
    public static void putPrice(ContentValues contentValues, String price){
        contentValues.put(PRICE, price);
    }

}
