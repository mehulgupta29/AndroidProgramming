package edu.stevens.cs522.bookstore.entities;

import android.database.Cursor;
import android.os.Parcel;
import android.os.Parcelable;

import edu.stevens.cs522.bookstore.contracts.AuthorContract;

public class Author implements Parcelable {
	
	// TODO Modify this to implement the Parcelable interface.

	// NOTE: middleInitial may be NULL!
	
	public String firstName;
	public String middleInitial;
	public String lastName;

    public Author(String firstName, String middleInitial, String lastName) {
        this.firstName = firstName;
        this.middleInitial = middleInitial;
        this.lastName = lastName;
    }

    public Author(String lastName, String firstName) {
        this.lastName = lastName;
        this.firstName = firstName;
    }

    public Author(String firstName) {
        this.firstName = firstName;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getMiddleInitial() {
        return middleInitial;
    }

    public void setMiddleInitial(String middleInitial) {
        this.middleInitial = middleInitial;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(firstName);
        dest.writeString(middleInitial);
        dest.writeString(lastName);
    }

    public Author(Parcel in){
        //same order as that in writeToParcel()
        firstName = in.readString();
        middleInitial = in.readString();
        lastName = in.readString();
    }

    public static final Parcelable.Creator<Author> CREATOR = new Parcelable.Creator<Author>() {
        public Author createFromParcel(Parcel in) {
            return new Author(in);
        }

        public Author[] newArray(int size) {
            return new Author[size];
        }
    };

    public String toString(){
        return firstName+middleInitial+lastName;
    }

    public Author(Cursor cursor){
        this.firstName = AuthorContract.getFirstName(cursor);
        this.middleInitial = AuthorContract.getMiddleInitial(cursor);
        this.lastName = AuthorContract.getLastName(cursor);
    }

    public static Author[] convert(Parcelable[] in){
        Author[] authors = new Author[in.length];
        System.arraycopy(in, 0, authors, 0, in.length);
        return authors;
    }
}
