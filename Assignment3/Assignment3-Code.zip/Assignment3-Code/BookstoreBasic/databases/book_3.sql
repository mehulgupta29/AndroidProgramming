select * from author;

SELECT b._id, title, GROUP_CONCAT(first_name||' '||COALESCE(middle_name,'-')||' '||last_name, "|") as authors, price, isbn FROM book as b LEFT OUTER JOIN author as a ON b._id = a.foreign_key GROUP BY b._id, title, price, isbn;

select GROUP_CONCAT(first_name||' '||COALESCE(middle_name,'-')||' '||last_name, "|") as authors from author group by foreign_key;